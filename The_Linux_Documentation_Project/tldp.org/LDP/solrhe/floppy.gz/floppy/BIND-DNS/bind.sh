#!/bin/sh
#
strip /usr/bin/addr
strip /usr/bin/dig
strip /usr/bin/dnsquery
strip /usr/bin/host
strip /usr/bin/nslookup
strip /usr/bin/nsupdate
strip /usr/bin/mkservdb
strip /usr/sbin/named
strip /usr/sbin/named-xfer
strip /usr/sbin/ndc
strip /usr/sbin/dnskeygen
strip /usr/sbin/irpd
mkdir /var/named
