#!/bin/sh
# Copy this script in the top directory where you're compile openldap
# and execute it with ./ldap.sh
#
install -d -m 700 /var/ldap
echo localhost > /etc/openldap/ldapserver
strip /usr/lib/liblber.so.1.0.0
strip /usr/lib/libldap.so.1.0.0
strip /usr/lib/libldap.a
strip /usr/lib/liblber.a
strip /usr/sbin/in.xfingerd
strip /usr/sbin/go500
strip /usr/sbin/go500gw
strip /usr/sbin/mail500
strip /usr/sbin/rp500
strip /usr/sbin/fax500
strip /usr/sbin/rcpt500
strip /usr/sbin/slapd
strip /usr/sbin/ldif2ldbm
strip /usr/sbin/ldif2index
strip /usr/sbin/ldif2id2entry
strip /usr/sbin/ldif2id2children
strip /usr/sbin/ldbmcat
strip /usr/sbin/ldif
strip /usr/sbin/centipede
strip /usr/sbin/ldbmtest
strip /usr/sbin/slurpd
strip /usr/bin/ud
strip /usr/bin/ldapadd
strip /usr/bin/ldapsearch
strip /usr/bin/ldapmodify
strip /usr/bin/ldapmodrdn
strip /usr/bin/ldappasswd
strip /usr/bin/ldapdelete
