#!/bin/sh
# Copy this script in the source subdirectory where you're compiled samba
# "/samba-dir/source/" and execute it with ./smb.sh
#
install -m 755 script/mksmbpasswd.sh /usr/bin/
rm -rf /usr/share/swat/
rm -f /usr/sbin/swat
rm -f /usr/man/man8/swat.8
mkdir -p /var/lock/samba
