#!/bin/sh
mkdir -p /var/log/squid
rm -rf /var/logs/
chown squid.squid /var/log/squid/
chmod 750 /var/log/squid/
chmod 750 /cache/
rm -f /usr/sbin/RunCache
rm -f /usr/sbin/RunAccel
strip /usr/sbin/squid
strip /usr/sbin/client
strip /usr/lib/squid/dnsserver
strip /usr/lib/squid/unlinkd
strip /usr/lib/squid/cachemgr.cgi
