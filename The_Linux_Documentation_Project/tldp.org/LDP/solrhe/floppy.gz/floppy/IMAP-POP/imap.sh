#!/bin/sh
# Copy this script in the top directory where you're compile imap
# and execute it with ./imap.sh
#
install -m 644 ./src/ipopd/ipopd.8c /usr/man/man8/ipopd.8c
install -m 644 ./src/imapd/imapd.8c /usr/man/man8/imapd.8c
install -s -m 755 ./ipopd/ipop2d /usr/sbin
install -s -m 755 ./ipopd/ipop3d /usr/sbin
install -s -m 755 ./imapd/imapd /usr/sbin
install -m 644 ./c-client/c-client.a /usr/lib
ln -fs /usr/lib/c-client.a /usr/lib/libimap.a
mkdir -p /usr/include/imap
install -m 644 ./c-client/*.h /usr/include/imap
install -m 644 ./src/osdep/tops-20/shortsym.h /usr/include/imap
chown root.mail /usr/sbin/ipop2d
chown root.mail /usr/sbin/ipop3d
chown root.mail /usr/sbin/imapd
