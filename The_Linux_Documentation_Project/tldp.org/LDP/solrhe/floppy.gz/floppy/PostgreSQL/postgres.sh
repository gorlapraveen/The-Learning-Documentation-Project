#!/bin/sh
#
mkdir -p /usr/include/pgsql
mv /usr/include/access /usr/include/pgsql/
mv /usr/include/commands /usr/include/pgsql/
mv /usr/include/executor /usr/include/pgsql/
mv /usr/include/lib  usr/include/pgsql/
mv /usr/include/libpq /usr/include/pgsql/
mv /usr/include/libpq++ /usr/include/pgsql/
mv /usr/include/port /usr/include/pgsql/
mv /usr/include/utils /usr/include/pgsql/
mv /usr/include/fmgr.h /usr/include/pgsql/
mv /usr/include/os.h /usr/include/pgsql/
mv /usr/include/config.h /usr/include/pgsql/
mv /usr/include/c.h /usr/include/pgsql/
mv /usr/include/postgres.h /usr/include/pgsql/
mv /usr/include/postgres_ext.h /usr/include/pgsql/
mv /usr/include/libpq-fe.h /usr/include/pgsql/
mv /usr/include/libpq-int.h /usr/include/pgsql/
mv /usr/include/ecpgerrno.h /usr/include/pgsql/
mv /usr/include/ecpglib.h /usr/include/pgsql/
mv /usr/include/ecpgtype.h /usr/include/pgsql/
mv /usr/include/sqlca.h /usr/include/pgsql/
mv /usr/include/libpq++.H /usr/include/pgsql/
mkdir -p /usr/lib/pgsql
mv /usr/lib/*source /usr/lib/pgsql/
mv /usr/lib/*sample /usr/lib/pgsql/
mkdir -p /var/lib/pgsql
chown -R postgres.postgres /var/lib/pgsql/
chmod 755 /usr/lib/libpq.so.2.0
chmod 755 /usr/lib/libecpg.so.3.0.0
chmod 755 /usr/lib/libpq++.so.3.0
strip /usr/bin/postgres
strip /usr/bin/postmaster
strip /usr/bin/ecpg
strip /usr/bin/pg_id
strip /usr/bin/pg_version
strip /usr/bin/pg_dump
strip /usr/bin/pg_passwd
strip /usr/bin/psql
rm -f /usr/lib/global1.description
rm -f /usr/lib/local1_template1.description
