#!/bin/sh
# Copy this script in the top directory where you're compile openssl
# and execute it with ./ssl.sh
#
mv /etc/ssl/misc/* /usr/bin/
rm -rf /etc/ssl/misc/
rm -rf /etc/ssl/lib/
rm -f /usr/bin/CA.pl
rm -f /usr/bin/CA.sh
install -m 644 libRSAglue.a /usr/lib/
install -m 644 rsaref/rsaref.h /usr/include/openssl/
strip /usr/bin/openssl
mkdir -p /etc/ssl/crl
