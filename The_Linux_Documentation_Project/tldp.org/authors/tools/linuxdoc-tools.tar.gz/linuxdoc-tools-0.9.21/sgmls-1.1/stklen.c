/* This tells Borland C++ to allocate a 14k stack. */
unsigned _stklen = 14*1024;
