README for DocBook 3.1

This is DocBook 3.1, released 01 Feb 1999.

See 31chg.txt for information about what has changed since DocBook 3.0.

For more information about DocBook, please see

  http://www.oasis-open.org/docbook/

Please send all questions, comments, concerns, and bug reports to the
DocBook mailing list: davenport@berkshire.net.
