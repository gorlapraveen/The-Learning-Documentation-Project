# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/fvwm-config-section/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ba:UNIX/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/commands-chapter/;
$ref_files{$key} = "$dir".q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/GNU-LGPL/;
$ref_files{$key} = "$dir".q|node165.html|; 
$noresave{$key} = "$nosave";

$key = q/x-start-stop-section/;
$ref_files{$key} = "$dir".q|node41.html|; 
$noresave{$key} = "$nosave";

$key = q/bootup-figure/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-mail-mode/;
$ref_files{$key} = "$dir".q|node98.html|; 
$noresave{$key} = "$nosave";

$key = q/x-chapter/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/standard-dirtree/;
$ref_files{$key} = "$dir".q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_St:Emacs/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/unixinfo/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-shot-1/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/bootup/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/GNU-GPL/;
$ref_files{$key} = "$dir".q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Al:LILO/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/twm-config-section/;
$ref_files{$key} = "$dir".q|node113.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-chapter/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/error-chapter/;
$ref_files{$key} = "$dir".q|node154.html|; 
$noresave{$key} = "$nosave";

$key = q/network-chapter/;
$ref_files{$key} = "$dir".q|node121.html|; 
$noresave{$key} = "$nosave";

$key = q/man-section/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/x11-menu-bar/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/shell2-chapter/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/section-multitasking/;
$ref_files{$key} = "$dir".q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/funny-chapter/;
$ref_files{$key} = "$dir".q|node132.html|; 
$noresave{$key} = "$nosave";

$key = q/full-x-screen/;
$ref_files{$key} = "$dir".q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/kernel-messages/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_La:LaTeX/;
$ref_files{$key} = "$dir".q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/job-control/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/aliasing-section/;
$ref_files{$key} = "$dir".q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/x11-scrollbar/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/shell-chapter/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/configuration-chapter/;
$ref_files{$key} = "$dir".q|node106.html|; 
$noresave{$key} = "$nosave";

$key = q/x-menus/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/env-variables/;
$ref_files{$key} = "$dir".q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/x-standard-options/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/linux-powerup/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/section-env-variables/;
$ref_files{$key} = "$dir".q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/sample-aliases/;
$ref_files{$key} = "$dir".q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/error-reporting/;
$ref_files{$key} = "$dir".q|node159.html|; 
$noresave{$key} = "$nosave";

$key = q/x-scroll-bar/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/intel-powerup/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

1;

