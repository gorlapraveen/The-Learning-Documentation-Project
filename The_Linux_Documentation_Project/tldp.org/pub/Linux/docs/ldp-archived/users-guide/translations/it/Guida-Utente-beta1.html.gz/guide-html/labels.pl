# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


$key = q/fvwm-config-section/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ba:UNIX/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/commands-chapter/;
$external_labels{$key} = "$URL/" . q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/GNU-LGPL/;
$external_labels{$key} = "$URL/" . q|node165.html|; 
$noresave{$key} = "$nosave";

$key = q/x-start-stop-section/;
$external_labels{$key} = "$URL/" . q|node41.html|; 
$noresave{$key} = "$nosave";

$key = q/bootup-figure/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-mail-mode/;
$external_labels{$key} = "$URL/" . q|node98.html|; 
$noresave{$key} = "$nosave";

$key = q/x-chapter/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/standard-dirtree/;
$external_labels{$key} = "$URL/" . q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_St:Emacs/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/unixinfo/;
$external_labels{$key} = "$URL/" . q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-shot-1/;
$external_labels{$key} = "$URL/" . q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/bootup/;
$external_labels{$key} = "$URL/" . q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/GNU-GPL/;
$external_labels{$key} = "$URL/" . q|node160.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Al:LILO/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/twm-config-section/;
$external_labels{$key} = "$URL/" . q|node113.html|; 
$noresave{$key} = "$nosave";

$key = q/emacs-chapter/;
$external_labels{$key} = "$URL/" . q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/error-chapter/;
$external_labels{$key} = "$URL/" . q|node154.html|; 
$noresave{$key} = "$nosave";

$key = q/network-chapter/;
$external_labels{$key} = "$URL/" . q|node121.html|; 
$noresave{$key} = "$nosave";

$key = q/man-section/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/x11-menu-bar/;
$external_labels{$key} = "$URL/" . q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/shell2-chapter/;
$external_labels{$key} = "$URL/" . q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/section-multitasking/;
$external_labels{$key} = "$URL/" . q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/funny-chapter/;
$external_labels{$key} = "$URL/" . q|node132.html|; 
$noresave{$key} = "$nosave";

$key = q/full-x-screen/;
$external_labels{$key} = "$URL/" . q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/kernel-messages/;
$external_labels{$key} = "$URL/" . q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_La:LaTeX/;
$external_labels{$key} = "$URL/" . q|node170.html|; 
$noresave{$key} = "$nosave";

$key = q/job-control/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/aliasing-section/;
$external_labels{$key} = "$URL/" . q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/x11-scrollbar/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/shell-chapter/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/configuration-chapter/;
$external_labels{$key} = "$URL/" . q|node106.html|; 
$noresave{$key} = "$nosave";

$key = q/x-menus/;
$external_labels{$key} = "$URL/" . q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/env-variables/;
$external_labels{$key} = "$URL/" . q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/x-standard-options/;
$external_labels{$key} = "$URL/" . q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/linux-powerup/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/section-env-variables/;
$external_labels{$key} = "$URL/" . q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/sample-aliases/;
$external_labels{$key} = "$URL/" . q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/error-reporting/;
$external_labels{$key} = "$URL/" . q|node159.html|; 
$noresave{$key} = "$nosave";

$key = q/x-scroll-bar/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/intel-powerup/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

1;

