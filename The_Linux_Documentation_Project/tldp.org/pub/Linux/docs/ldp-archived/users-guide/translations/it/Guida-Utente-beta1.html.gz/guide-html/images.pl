# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{screen}preform<verbatim_mark>verbatim69#preform{screen}AAT;/;
$cached_env_img{$key} = q|95#95|; 

$key = q/{screen}preform<verbatim_mark>verbatim100#preform{screen}AAT;/;
$cached_env_img{$key} = q|157#157|; 

$key = q/{screen}preform<verbatim_mark>verbatim102#preform{screen}AAT;/;
$cached_env_img{$key} = q|159#159|; 

$key = q/{screen}preform<verbatim_mark>verbatim104#preform{screen}AAT;/;
$cached_env_img{$key} = q|161#161|; 

$key = q/{screen}preform<verbatim_mark>verbatim106#preform{screen}AAT;/;
$cached_env_img{$key} = q|163#163|; 

$key = q/{screen}preform<verbatim_mark>verbatim108#preform{screen}AAT;/;
$cached_env_img{$key} = q|165#165|; 

$key = q/{figure}screenpreform<verbatim_mark>verbatim84#preformscreen{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|140#140|; 

$key = q/{}fboxsff{}AAT;/;
$cached_env_img{$key} = q|119#119|; 

$key = q/{}fboxsfCtrl-d{}AAT;/;
$cached_env_img{$key} = q|38#38|; 

$key = q/{figure}centertabular|l|p.4linewidth|p.4linewidth|hlineNome&Seguitoda&Esempiohlig&coloreprimariodellosfondo&ttxterm-bgbluehlinetabularcenter{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|67#67|; 

$key = q/{figure}centertabular|l|l|l|hlinemulticolumn1|c|Variabile&multicolumn1c|ContienesrslashbinslashX11&incuicercareiprogrammi&hlinetabularcenter{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|147#147|; 

$key = q/{inline}times{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|170#170|; 

$key = q/{}fboxsfTasto{}AAT;/;
$cached_env_img{$key} = q|3#3|; 

$key = q/{screen}preform<verbatim_mark>verbatim31#preform{screen}AAT;/;
$cached_env_img{$key} = q|44#44|; 

$key = q/{screen}tt;;questeduelineevengonoignoratedall'interpreteLisp,ma;;l'espressionesepieno:(setquna-stringa-letterale"Unastranapausa;pernessunmotivo.")tt{screen}AAT;/;
$cached_env_img{$key} = q|135#135|; 

$key = q/{}fboxsfn{}AAT;/;
$cached_env_img{$key} = q|110#110|; 

$key = q/{screen}preform<verbatim_mark>verbatim33#preform{screen}AAT;/;
$cached_env_img{$key} = q|46#46|; 

$key = q/{screen}preform<verbatim_mark>verbatim70#preform{screen}AAT;/;
$cached_env_img{$key} = q|96#96|; 

$key = q/{screen}preform<verbatim_mark>verbatim35#preform{screen}AAT;/;
$cached_env_img{$key} = q|48#48|; 

$key = q/{screen}preform<verbatim_mark>verbatim72#preform{screen}AAT;/;
$cached_env_img{$key} = q|98#98|; 

$key = q/{screen}preform<verbatim_mark>verbatim37#preform{screen}AAT;/;
$cached_env_img{$key} = q|50#50|; 

$key = q/{screen}preform<verbatim_mark>verbatim74#preform{screen}AAT;/;
$cached_env_img{$key} = q|101#101|; 

$key = q/{screen}preform<verbatim_mark>verbatim39#preform{screen}AAT;/;
$cached_env_img{$key} = q|52#52|; 

$key = q/{screen}tttt>(rotate'(abcde))tt{screen}AAT;/;
$cached_env_img{$key} = q|129#129|; 

$key = q/{screen}preform<verbatim_mark>verbatim76#preform{screen}AAT;/;
$cached_env_img{$key} = q|114#114|; 

$key = q/{screen}preform<verbatim_mark>verbatim78#preform{screen}AAT;/;
$cached_env_img{$key} = q|120#120|; 

$key = q/{}fboxsfF3{}AAT;/;
$cached_env_img{$key} = q|105#105|; 

$key = q/{}fboxsfEsc{}AAT;/;
$cached_env_img{$key} = q|124#124|; 

$key = q/{}fboxsfslash{}AAT;/;
$cached_env_img{$key} = q|109#109|; 

$key = q/{screen}preform<verbatim_mark>verbatim2#preform{screen}AAT;/;
$cached_env_img{$key} = q|9#9|; 

$key = q/{screen}preform<verbatim_mark>verbatim4#preform{screen}AAT;/;
$cached_env_img{$key} = q|11#11|; 

$key = q/{}fboxsfShift{}AAT;/;
$cached_env_img{$key} = q|128#128|; 

$key = q/{screen}preform<verbatim_mark>verbatim6#preform{screen}AAT;/;
$cached_env_img{$key} = q|13#13|; 

$key = q/{screen}preform<verbatim_mark>verbatim8#preform{screen}AAT;/;
$cached_env_img{$key} = q|15#15|; 

$key = q/{screen}preform<verbatim_mark>verbatim119#preform{screen}AAT;/;
$cached_env_img{$key} = q|172#172|; 

$key = q/{}fboxsfCtrl-C{}AAT;/;
$cached_env_img{$key} = q|82#82|; 

$key = q/{}epsfboxps-filesslashscreen-shot-2.ps{}AAT;/;
$cached_env_img{$key} = q|122#122|; 

$key = q/{screen}preform<verbatim_mark>verbatim40#preform{screen}AAT;/;
$cached_env_img{$key} = q|53#53|; 

$key = q/{screen}preform<verbatim_mark>verbatim42#preform{screen}AAT;/;
$cached_env_img{$key} = q|55#55|; 

$key = q/{screen}preform<verbatim_mark>verbatim44#preform{screen}AAT;/;
$cached_env_img{$key} = q|57#57|; 

$key = q/{screen}preform<verbatim_mark>verbatim46#preform{screen}AAT;/;
$cached_env_img{$key} = q|60#60|; 

$key = q/{tscreen}slashhomeslashlarrydollarcatslAiuto!SonoincastratoinunprogrammaLinux!Aiuto!SonoincastratoinunprogrammaLinux!{tscreen}AAT;/;
$cached_env_img{$key} = q|37#37|; 

$key = q/{screen}preform<verbatim_mark>verbatim83#preform{screen}AAT;/;
$cached_env_img{$key} = q|139#139|; 

$key = q/{screen}preform<verbatim_mark>verbatim48#preform{screen}AAT;/;
$cached_env_img{$key} = q|62#62|; 

$key = q/{screen}preform<verbatim_mark>verbatim85#preform{screen}AAT;/;
$cached_env_img{$key} = q|141#141|; 

$key = q/{screen}preform<verbatim_mark>verbatim87#preform{screen}AAT;/;
$cached_env_img{$key} = q|143#143|; 

$key = q/{screen}preform<verbatim_mark>verbatim89#preform{screen}AAT;/;
$cached_env_img{$key} = q|145#145|; 

$key = q/{screen}preform<verbatim_mark>verbatim120#preform{screen}AAT;/;
$cached_env_img{$key} = q|173#173|; 

$key = q/{}fboxsfControl{}AAT;/;
$cached_env_img{$key} = q|118#118|; 

$key = q/{}useboxcaution{}AAT;/;
$cached_env_img{$key} = q|2#2|; 

$key = q/{}fboxsfInvio{}AAT;/;
$cached_env_img{$key} = q|4#4|; 

$key = q/{}fboxsfBarraspaziatrice{}AAT;/;
$cached_env_img{$key} = q|107#107|; 

$key = q/{screen}preform<verbatim_mark>verbatim10#preform{screen}AAT;/;
$cached_env_img{$key} = q|17#17|; 

$key = q/{figure}centerleavevmodeepsfxsize=5inepsfboxps-filesslashscreen-shot-1.pscenter{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|117#117|; 

$key = q/{screen}preform<verbatim_mark>verbatim12#preform{screen}AAT;/;
$cached_env_img{$key} = q|19#19|; 

$key = q/{screen}preform<verbatim_mark>verbatim14#preform{screen}AAT;/;
$cached_env_img{$key} = q|21#21|; 

$key = q/{screen}preform<verbatim_mark>verbatim51#preform{screen}AAT;/;
$cached_env_img{$key} = q|72#72|; 

$key = q/{screen}preform<verbatim_mark>verbatim16#preform{screen}AAT;/;
$cached_env_img{$key} = q|23#23|; 

$key = q/{screen}preform<verbatim_mark>verbatim53#preform{screen}AAT;/;
$cached_env_img{$key} = q|74#74|; 

$key = q/{}fboxsfq{}AAT;/;
$cached_env_img{$key} = q|41#41|; 

$key = q/{screen}preform<verbatim_mark>verbatim90#preform{screen}AAT;/;
$cached_env_img{$key} = q|146#146|; 

$key = q/{screen}preform<verbatim_mark>verbatim18#preform{screen}AAT;/;
$cached_env_img{$key} = q|25#25|; 

$key = q/{screen}preform<verbatim_mark>verbatim55#preform{screen}AAT;/;
$cached_env_img{$key} = q|78#78|; 

$key = q/{screen}preform<verbatim_mark>verbatim92#preform{screen}AAT;/;
$cached_env_img{$key} = q|149#149|; 

$key = q/{screen}preform<verbatim_mark>verbatim57#preform{screen}AAT;/;
$cached_env_img{$key} = q|80#80|; 

$key = q/{screen}preform<verbatim_mark>verbatim94#preform{screen}AAT;/;
$cached_env_img{$key} = q|151#151|; 

$key = q/{screen}preform<verbatim_mark>verbatim59#preform{screen}AAT;/;
$cached_env_img{$key} = q|84#84|; 

$key = q/{}fboxsfF2{}AAT;/;
$cached_env_img{$key} = q|103#103|; 

$key = q/{screen}preform<verbatim_mark>verbatim96#preform{screen}AAT;/;
$cached_env_img{$key} = q|153#153|; 

$key = q/{screen}tt(global-set-key"<verb_mark>12<verb_mark>C-cl"'goto-line)tt{screen}AAT;/;
$cached_env_img{$key} = q|132#132|; 

$key = q/{screen}preform<verbatim_mark>verbatim98#preform{screen}AAT;/;
$cached_env_img{$key} = q|155#155|; 

$key = q/{}fboxsfctrl-c{}AAT;/;
$cached_env_img{$key} = q|64#64|; 

$key = q/{inline}pm{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|66#66|; 

$key = q/{screen}preform<verbatim_mark>verbatim21#preform{screen}AAT;/;
$cached_env_img{$key} = q|30#30|; 

$key = q/{figure}centerepsfigfile=ps-filesslashscreen-shot-3.ps,height=3inhspace0.7inepsfigfile=ps-filesslashscreen-shot-4.ps,height=3incenter{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|69#69|; 

$key = q/{screen}preform<verbatim_mark>verbatim23#preform{screen}AAT;/;
$cached_env_img{$key} = q|32#32|; 

$key = q/{screen}preform<verbatim_mark>verbatim60#preform{screen}AAT;/;
$cached_env_img{$key} = q|85#85|; 

$key = q/{screen}preform<verbatim_mark>verbatim25#preform{screen}AAT;/;
$cached_env_img{$key} = q|34#34|; 

$key = q/{screen}preform<verbatim_mark>verbatim62#preform{screen}AAT;/;
$cached_env_img{$key} = q|87#87|; 

$key = q/{screen}preform<verbatim_mark>verbatim64#preform{screen}AAT;/;
$cached_env_img{$key} = q|89#89|; 

$key = q/{screen}preform<verbatim_mark>verbatim66#preform{screen}AAT;/;
$cached_env_img{$key} = q|91#91|; 

$key = q/{}fboxsfCanc{}AAT;/;
$cached_env_img{$key} = q|126#126|; 

$key = q/{inline}backslash{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|169#169|; 

$key = q/{screen}preform<verbatim_mark>verbatim68#preform{screen}AAT;/;
$cached_env_img{$key} = q|94#94|; 

$key = q/{screen}preform<verbatim_mark>verbatim101#preform{screen}AAT;/;
$cached_env_img{$key} = q|158#158|; 

$key = q/{screen}preform<verbatim_mark>verbatim*27#preform{screen}AAT;/;
$cached_env_img{$key} = q|36#36|; 

$key = q/{}fboxsfCtrl-Z{}AAT;/;
$cached_env_img{$key} = q|83#83|; 

$key = q/{screen}preform<verbatim_mark>verbatim103#preform{screen}AAT;/;
$cached_env_img{$key} = q|160#160|; 

$key = q/{screen}tt(setqcase-fold-searchnil);nonconsideralemaiuscolenellericerche;;farientrareiprogrammiCcomepiaceame:(setqc-indent-level2)tt{screen}AAT;/;
$cached_env_img{$key} = q|134#134|; 

$key = q/{}fboxsfBackspace{}AAT;/;
$cached_env_img{$key} = q|121#121|; 

$key = q/{screen}preform<verbatim_mark>verbatim105#preform{screen}AAT;/;
$cached_env_img{$key} = q|162#162|; 

$key = q/{screen}preform<verbatim_mark>verbatim107#preform{screen}AAT;/;
$cached_env_img{$key} = q|164#164|; 

$key = q/{figure}picture(148.00,365.00)(0.00,450.00)put(9.00,805.00)line(1,0)29.00%slash-box(0,0)[lc]linuxput(86.00,455.00)makebox(0,0)[lc]tmppicture{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|42#42|; 

$key = q/{screen}preform<verbatim_mark>verbatim109#preform{screen}AAT;/;
$cached_env_img{$key} = q|166#166|; 

$key = q/{}fboxsfd{}AAT;/;
$cached_env_img{$key} = q|108#108|; 

$key = q/{}fboxsfMeta{}AAT;/;
$cached_env_img{$key} = q|127#127|; 

$key = q/{screen}preform<verbatim_mark>verbatim30#preform{screen}AAT;/;
$cached_env_img{$key} = q|43#43|; 

$key = q/{screen}preform<verbatim_mark>verbatim32#preform{screen}AAT;/;
$cached_env_img{$key} = q|45#45|; 

$key = q/{screen}preform<verbatim_mark>verbatim34#preform{screen}AAT;/;
$cached_env_img{$key} = q|47#47|; 

$key = q/{}fboxsfp{}AAT;/;
$cached_env_img{$key} = q|112#112|; 

$key = q/{figure}centeringepsfigfile=ps-filesslashbootup-figure.ps,width=.9linewidth{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|8#8|; 

$key = q/{screen}preform<verbatim_mark>verbatim71#preform{screen}AAT;/;
$cached_env_img{$key} = q|97#97|; 

$key = q/{screen}preform<verbatim_mark>verbatim36#preform{screen}AAT;/;
$cached_env_img{$key} = q|49#49|; 

$key = q/{screen}preform<verbatim_mark>verbatim73#preform{screen}AAT;/;
$cached_env_img{$key} = q|100#100|; 

$key = q/{screen}preform<verbatim_mark>verbatim38#preform{screen}AAT;/;
$cached_env_img{$key} = q|51#51|; 

$key = q/{screen}preform<verbatim_mark>verbatim75#preform{screen}AAT;/;
$cached_env_img{$key} = q|113#113|; 

$key = q/{}useboxxlogo{}AAT;/;
$cached_env_img{$key} = q|1#1|; 

$key = q/{}fboxsfTab{}AAT;/;
$cached_env_img{$key} = q|77#77|; 

$key = q/{}fboxsfF1{}AAT;/;
$cached_env_img{$key} = q|104#104|; 

$key = q/{screen}preform<verbatim_mark>verbatim77#preform{screen}AAT;/;
$cached_env_img{$key} = q|115#115|; 

$key = q/{screen}preform<verbatim_mark>verbatim79#preform{screen}AAT;/;
$cached_env_img{$key} = q|123#123|; 

$key = q/{screen}preform<verbatim_mark>verbatim1#preform{screen}AAT;/;
$cached_env_img{$key} = q|7#7|; 

$key = q/{screen}preform<verbatim_mark>verbatim110#preform{screen}AAT;/;
$cached_env_img{$key} = q|167#167|; 

$key = q/{screen}preform<verbatim_mark>verbatim3#preform{screen}AAT;/;
$cached_env_img{$key} = q|10#10|; 

$key = q/{}fboxsfctrl-Z{}AAT;/;
$cached_env_img{$key} = q|93#93|; 

$key = q/{inline}51slash4{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|26#26|; 

$key = q/{screen}preform<verbatim_mark>verbatim5#preform{screen}AAT;/;
$cached_env_img{$key} = q|12#12|; 

$key = q/{screen}preform<verbatim_mark>verbatim7#preform{screen}AAT;/;
$cached_env_img{$key} = q|14#14|; 

$key = q/{screen}preform<verbatim_mark>verbatim9#preform{screen}AAT;/;
$cached_env_img{$key} = q|16#16|; 

$key = q/{screen}preform<verbatim_mark>verbatim118#preform{screen}AAT;/;
$cached_env_img{$key} = q|171#171|; 

$key = q/{inline}Diamond{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|5#5|; 

$key = q/{screen}tt;;notatecomel'espressionepu`oesserespezzatainpi`ulinee.IlLisp;;ingenerd'run-scheme"cmuscheme""AvviaunoSchemeinferiore,comelovoglioio."t)tt{screen}AAT;/;
$cached_env_img{$key} = q|138#138|; 

$key = q/{screen}preform<verbatim_mark>verbatim41#preform{screen}AAT;/;
$cached_env_img{$key} = q|54#54|; 

$key = q/{screen}preform<verbatim_mark>verbatim43#preform{screen}AAT;/;
$cached_env_img{$key} = q|56#56|; 

$key = q/{screen}preform<verbatim_mark>verbatim45#preform{screen}AAT;/;
$cached_env_img{$key} = q|59#59|; 

$key = q/{screen}preform<verbatim_mark>verbatim82#preform{screen}AAT;/;
$cached_env_img{$key} = q|137#137|; 

$key = q/{screen}preform<verbatim_mark>verbatim47#preform{screen}AAT;/;
$cached_env_img{$key} = q|61#61|; 

$key = q/{screen}preform<verbatim_mark>verbatim49#preform{screen}AAT;/;
$cached_env_img{$key} = q|70#70|; 

$key = q/{screen}preform<verbatim_mark>verbatim86#preform{screen}AAT;/;
$cached_env_img{$key} = q|142#142|; 

$key = q/{screen}preform<verbatim_mark>verbatim88#preform{screen}AAT;/;
$cached_env_img{$key} = q|144#144|; 

$key = q/{}fboxsfctrl-z{}AAT;/;
$cached_env_img{$key} = q|99#99|; 

$key = q/{}fboxsfCtrl-]{}AAT;/;
$cached_env_img{$key} = q|168#168|; 

$key = q/{}fboxsfAlt{}AAT;/;
$cached_env_img{$key} = q|65#65|; 

$key = q/{screen}ttload-pathtt{screen}AAT;/;
$cached_env_img{$key} = q|130#130|; 

$key = q/{screen}preform<verbatim_mark>verbatim11#preform{screen}AAT;/;
$cached_env_img{$key} = q|18#18|; 

$key = q/{figure}centerepsfigfile=ps-filesslashscreen-shot-2.ps,width=textwidthcenter{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|68#68|; 

$key = q/{screen}preform<verbatim_mark>verbatim13#preform{screen}AAT;/;
$cached_env_img{$key} = q|20#20|; 

$key = q/{figure}indexshell!controllodeijob!riassuntodispitemsitemttfgsl%job`Euncomandodiosospeso,iljobpu`oessereavviatoinbackgroundoucciso.dispitems{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|102#102|; 

$key = q/{screen}preform<verbatim_mark>verbatim50#preform{screen}AAT;/;
$cached_env_img{$key} = q|71#71|; 

$key = q/{screen}preform<verbatim_mark>verbatim15#preform{screen}AAT;/;
$cached_env_img{$key} = q|22#22|; 

$key = q/{figure}centeringepsfigfile=ps-filesslashscreen-shot-5.ps,width=linewidth{figure}FSF=1.6;AAT;/;
$cached_env_img{$key} = q|63#63|; 

$key = q/{screen}preform<verbatim_mark>verbatim52#preform{screen}AAT;/;
$cached_env_img{$key} = q|73#73|; 

$key = q/{screen}preform<verbatim_mark>verbatim17#preform{screen}AAT;/;
$cached_env_img{$key} = q|24#24|; 

$key = q/{screen}preform<verbatim_mark>verbatim54#preform{screen}AAT;/;
$cached_env_img{$key} = q|76#76|; 

$key = q/{screen}preform<verbatim_mark>verbatim19#preform{screen}AAT;/;
$cached_env_img{$key} = q|28#28|; 

$key = q/{screen}preform<verbatim_mark>verbatim91#preform{screen}AAT;/;
$cached_env_img{$key} = q|148#148|; 

$key = q/{screen}preform<verbatim_mark>verbatim56#preform{screen}AAT;/;
$cached_env_img{$key} = q|79#79|; 

$key = q/{screen}preform<verbatim_mark>verbatim93#preform{screen}AAT;/;
$cached_env_img{$key} = q|150#150|; 

$key = q/{screen}preform<verbatim_mark>verbatim58#preform{screen}AAT;/;
$cached_env_img{$key} = q|81#81|; 

$key = q/{screen}preform<verbatim_mark>verbatim95#preform{screen}AAT;/;
$cached_env_img{$key} = q|152#152|; 

$key = q/{screen}preform<verbatim_mark>verbatim97#preform{screen}AAT;/;
$cached_env_img{$key} = q|154#154|; 

$key = q/{}fboxsf:{}AAT;/;
$cached_env_img{$key} = q|111#111|; 

$key = q/{inline}31slash2{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|27#27|; 

$key = q/{screen}preform<verbatim_mark>verbatim99#preform{screen}AAT;/;
$cached_env_img{$key} = q|156#156|; 

$key = q/{screen}tt(setqinhibit-startup-messaget)tt{screen}AAT;/;
$cached_env_img{$key} = q|133#133|; 

$key = q/{screen}tt(load"c-mode");forzaEmacsacaricarloinc-mode.elo.elctt{screen}AAT;/;
$cached_env_img{$key} = q|136#136|; 

$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|6#6|; 

$key = q/{screen}preform<verbatim_mark>verbatim20#preform{screen}AAT;/;
$cached_env_img{$key} = q|29#29|; 

$key = q/{screen}preform<verbatim_mark>verbatim22#preform{screen}AAT;/;
$cached_env_img{$key} = q|31#31|; 

$key = q/{screen}ttttslashhomeslashlarrydollaremacsREADMEtt{screen}AAT;/;
$cached_env_img{$key} = q|116#116|; 

$key = q/{}fboxsfCtrl-L{}AAT;/;
$cached_env_img{$key} = q|106#106|; 

$key = q/{screen}preform<verbatim_mark>verbatim24#preform{screen}AAT;/;
$cached_env_img{$key} = q|33#33|; 

$key = q/{screen}preform<verbatim_mark>verbatim61#preform{screen}AAT;/;
$cached_env_img{$key} = q|86#86|; 

$key = q/{inline}n^rmmo{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|58#58|; 

$key = q/{screen}ttload-pathfboxsfC-j,("slashusrslashlibslashemacsslashsite-lispslashvm-5acsslashsite-lisp""slashusrslashlibslashemacsslash19.19slashlisp")tt{screen}AAT;/;
$cached_env_img{$key} = q|131#131|; 

$key = q/{screen}preform<verbatim_mark>verbatim26#preform{screen}AAT;/;
$cached_env_img{$key} = q|35#35|; 

$key = q/{screen}preform<verbatim_mark>verbatim63#preform{screen}AAT;/;
$cached_env_img{$key} = q|88#88|; 

$key = q/{}fboxsfDelete{}AAT;/;
$cached_env_img{$key} = q|125#125|; 

$key = q/{screen}preform<verbatim_mark>verbatim28#preform{screen}AAT;/;
$cached_env_img{$key} = q|39#39|; 

$key = q/{screen}preform<verbatim_mark>verbatim65#preform{screen}AAT;/;
$cached_env_img{$key} = q|90#90|; 

$key = q/{screen}preform<verbatim_mark>verbatim67#preform{screen}AAT;/;
$cached_env_img{$key} = q|92#92|; 

$key = q/{}fboxsfCtrl-T{}AAT;/;
$cached_env_img{$key} = q|75#75|; 

$key = q/{}fboxsfSpazio{}AAT;/;
$cached_env_img{$key} = q|40#40|; 

1;

