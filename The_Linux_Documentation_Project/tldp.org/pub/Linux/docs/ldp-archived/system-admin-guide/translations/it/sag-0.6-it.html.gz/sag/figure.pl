'<LI><A HREF="'.$dir.'node8.html#418">Alcune delle parti pi� importanti del kernel Linux.</A>
<LI><A HREF="'.$dir.'node22.html#803">Parti di un albero delle directory Unix.
			Le linee tratteggiate indicano i limiti delle partizioni.</A>
<LI><A HREF="'.$dir.'node31.html#1499">Schema di un hard disk.</A>
<LI><A HREF="'.$dir.'node38.html#1587">Un esempio di partizionamento di hard disk.</A>
<LI><A HREF="'.$dir.'node47.html#1692">Tre filesystem separati.</A>
<LI><A HREF="'.$dir.'node47.html#1895">Sono stati montati <TT>/home</TT></A><A NAME="2052">&#160;</A> e <TT>/usr</TT><A NAME="2054">&#160;</A>.
<LI><A HREF="'.$dir.'node52.html#1899">Output di esempio di <TT>dumpe2fs</TT></A><A NAME="2218">&#160;</A>
<LI><A HREF="'.$dir.'node81.html#3900">Login via terminale: l'interazione di <TT>init</TT></A><A NAME="3923">&#160;</A>, <TT>getty</TT><A NAME="3925">&#160;</A>,
	<TT>login</TT><A NAME="3927">&#160;</A>, e la shell.
<LI><A HREF="'.$dir.'node104.html#4469">Un esempio di backup multilivello.</A>
<LI><A HREF="'.$dir.'node104.html#4475">Un efficace schema di backup usando molti livelli</A>'
