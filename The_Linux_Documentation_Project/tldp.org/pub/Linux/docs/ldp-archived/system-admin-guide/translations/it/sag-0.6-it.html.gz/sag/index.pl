# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate index original text with physical files.


$key = q/messaggi di avvertimento/;
$index{$key} .= q|<A HREF="|."$dir".q|node12.html#471">4.3.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/home\/students/;
$index{$key} .= q|<A HREF="|."$dir".q|node22.html#1037">5.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/var/;
$index{$key} .= q|<A HREF="|."$dir".q|node22.html#1051">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1055">5.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc.d/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1109">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/terminfo/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1202">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ctrl-alt-del/;
$index{$key} .= q|<A HREF="|."$dir".q|node71.html#3193">8.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bdflush/;
$index{$key} .= q|<A HREF="|."$dir".q|node51.html#2198">6.8.9</A>
 \| <A HREF="|."$dir".q|node66.html#2918">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2922">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2926">7.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/unmount di filesystem/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#452">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/lib\/modules/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1071">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/who/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3982">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/demoniinizializzazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3137">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/rdev/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2100">6.8.5</A>
 \| <A HREF="|."$dir".q|node69.html#3236">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3238">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/adm\/messages/;
$index{$key} .= q|<A HREF="|."$dir".q|node35.html#1966">6.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mkfs/;
$index{$key} .= q|<A HREF="|."$dir".q|node3.html#192">3</A>
 \| <A HREF="|."$dir".q|node35.html#1974">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1980">6.6</A>
 \| <A HREF="|."$dir".q|node46.html#2028">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2030">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2032">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2038">6.8.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/proc/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1318">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/e-mail/;
$index{$key} .= q|<i>see </i> posta elettronica
 \| |; 
$noresave{$key} = "$nosave";

$key = q/dump/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2135">6.8.5</A>
 \| <A HREF="|."$dir".q|node52.html#2226">6.8.10</A>
 \| <A HREF="|."$dir".q|node100.html#4510">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4520">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4530">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4532">12.3</A>
 \| <A HREF="|."$dir".q|node104.html#4567">12.5</A>
 \| <A HREF="|."$dir".q|node104.html#4569">12.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bsd/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#427">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cache di buffer/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#422">4.2</A>
 \| <A HREF="|."$dir".q|node68.html#3082">8.1</A>
 \| <A HREF="|."$dir".q|node70.html#3149">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3180">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/sbin/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1061">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/mnt/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1083">5.2</A>
 \| <A HREF="|."$dir".q|node23.html#1085">5.2</A>
 \| <A HREF="|."$dir".q|node23.html#1087">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/nethack/;
$index{$key} .= q|<A HREF="|."$dir".q|node78.html#3702">9.4</A>
 \| <A HREF="|."$dir".q|node79.html#3709">9.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/modalit� utente/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#401">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/.profile/;
$index{$key} .= q|<A HREF="|."$dir".q|node86.html#4026">10.6</A>
 \| <A HREF="|."$dir".q|node86.html#4030">10.6</A>
 \| <A HREF="|."$dir".q|node92.html#4241">11.2.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/umask/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2145">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/posta elettronica/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#517">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/root/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#588">4.3.1</A>
 \| <A HREF="|."$dir".q|node47.html#2121">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2125">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/exec/;
$index{$key} .= q|<A HREF="|."$dir".q|node81.html#3937">10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdownusando/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3154">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man\/man*/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1262">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/telnet/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#572">4.1</A>
 \| <A HREF="|."$dir".q|node16.html#638">4.3.7</A>
 \| <A HREF="|."$dir".q|node16.html#644">4.3.7</A>
 \| <A HREF="|."$dir".q|node82.html#3954">10.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/clock/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4809">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4813">13.3</A>
 \| <A HREF="|."$dir".q|node111.html#4823">13.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/compressione del kernel/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3109">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/motd/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1155">5.2.1</A>
 \| <A HREF="|."$dir".q|node83.html#3964">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fips/;
$index{$key} .= q|<A HREF="|."$dir".q|node40.html#2008">6.7.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bootingda floppy/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3097">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/top/;
$index{$key} .= q|<A HREF="|."$dir".q|node63.html#2889">7.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bootstrap loader/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3077">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/swapon/;
$index{$key} .= q|<A HREF="|."$dir".q|node63.html#2879">7.3</A>
 \| <A HREF="|."$dir".q|node63.html#2885">7.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/makedev/;
$index{$key} .= q|<A HREF="|."$dir".q|node25.html#1208">5.2.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/printcap/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1174">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/makedev/;
$index{$key} .= q|<A HREF="|."$dir".q|node25.html#1212">5.2.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/hard diskboot da/;
$index{$key} .= q|<i>see </i> booting
 \| |; 
$noresave{$key} = "$nosave";

$key = q/vipw/;
$index{$key} .= q|<A HREF="|."$dir".q|node93.html#4247">11.2.4</A>
 \| <A HREF="|."$dir".q|node93.html#4249">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4277">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/utmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3986">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3996">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#4000">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/kcore/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1336">5.5</A>
 \| <A HREF="|."$dir".q|node44.html#2026">6.8.2</A>
 \| <A HREF="|."$dir".q|node105.html#4577">12.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/ksyms/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1344">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/crontab/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#628">4.3.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/floppy-image/;
$index{$key} .= q|<A HREF="|."$dir".q|node53.html#2238">6.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/rlogin/;
$index{$key} .= q|<A HREF="|."$dir".q|node16.html#640">4.3.7</A>
 \| <A HREF="|."$dir".q|node16.html#646">4.3.7</A>
 \| <A HREF="|."$dir".q|node82.html#3956">10.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/lpr/;
$index{$key} .= q|<A HREF="|."$dir".q|node30.html#1902">6.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/tty1/;
$index{$key} .= q|<A HREF="|."$dir".q|node76.html#3643">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3645">9.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/loadavg/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1346">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/deluser/;
$index{$key} .= q|<A HREF="|."$dir".q|node95.html#4293">11.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/accetta/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3179">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ls -l/;
$index{$key} .= q|<A HREF="|."$dir".q|node30.html#1908">6.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/csh.cshrc/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1182">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/boot record della partizione/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3094">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/double/;
$index{$key} .= q|<A HREF="|."$dir".q|node59.html#2276">6.10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/magic/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1145">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/tty/;
$index{$key} .= q|<A HREF="|."$dir".q|node76.html#3639">9.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/accendere il computer/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3075">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/init/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#434">4.3.1</A>
 \| <A HREF="|."$dir".q|node69.html#3242">8.2</A>
 \| <A HREF="|."$dir".q|node74.html#3418">9</A>
 \| <A HREF="|."$dir".q|node75.html#3583">9.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ls/;
$index{$key} .= q|<A HREF="|."$dir".q|node30.html#1906">6.1</A>
 \| <A HREF="|."$dir".q|node30.html#1910">6.1</A>
 \| <A HREF="|."$dir".q|node66.html#2903">7.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/motif/;
$index{$key} .= q|<A HREF="|."$dir".q|node14.html#491">4.3.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/adm\/messages/;
$index{$key} .= q|<A HREF="|."$dir".q|node22.html#1047">5.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/debugfs/;
$index{$key} .= q|<A HREF="|."$dir".q|node48.html#2173">6.8.6</A>
 \| <A HREF="|."$dir".q|node52.html#2220">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2224">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/boot recordmaster/;
$index{$key} .= q|<i>see </i> MBR
 \| |; 
$noresave{$key} = "$nosave";

$key = q/file system di rete/;
$index{$key} .= q|<A HREF="|."$dir".q|node17.html#512">4.3.8</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bootmessaggi/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3118">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib\/libc.a/;
$index{$key} .= q|<A HREF="|."$dir".q|node22.html#1045">5.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tar/;
$index{$key} .= q|<A HREF="|."$dir".q|node53.html#2230">6.9</A>
 \| <A HREF="|."$dir".q|node53.html#2232">6.9</A>
 \| <A HREF="|."$dir".q|node100.html#4506">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4512">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4516">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4522">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4526">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4534">12.3</A>
 \| <A HREF="|."$dir".q|node102.html#4540">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4540">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4542">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4544">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4546">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4548">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4550">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4552">12.4.1</A>
 \| <A HREF="|."$dir".q|node102.html#4554">12.4.1</A>
 \| <A HREF="|."$dir".q|node103.html#4558">12.4.2</A>
 \| <A HREF="|."$dir".q|node103.html#4558">12.4.2</A>
 \| <A HREF="|."$dir".q|node103.html#4560">12.4.2</A>
 \| <A HREF="|."$dir".q|node103.html#4562">12.4.2</A>
 \| <A HREF="|."$dir".q|node103.html#4564">12.4.2</A>
 \| <A HREF="|."$dir".q|node104.html#4571">12.5</A>
 \| <A HREF="|."$dir".q|node106.html#4585">12.7</A>
 \| <A HREF="|."$dir".q|node106.html#4589">12.7</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/socket/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#428">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1252">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1250">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/nologin/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3968">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/run\/utmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1298">5.4</A>
 \| <A HREF="|."$dir".q|node83.html#3980">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd0/;
$index{$key} .= q|<A HREF="|."$dir".q|node32.html#1939">6.3</A>
 \| <A HREF="|."$dir".q|node35.html#1956">6.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/w/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3984">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/tmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#624">4.3.4</A>
 \| <A HREF="|."$dir".q|node23.html#1077">5.2</A>
 \| <A HREF="|."$dir".q|node27.html#1306">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1310">5.4</A>
 \| <A HREF="|."$dir".q|node47.html#2080">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2084">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2088">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2092">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2094">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd1/;
$index{$key} .= q|<A HREF="|."$dir".q|node32.html#1941">6.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/net/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1352">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/configurazione dell'hardware/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3115">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/programma applicativo/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#396">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/sbin/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1240">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/vmlinuz/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1057">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/badblocks/;
$index{$key} .= q|<A HREF="|."$dir".q|node35.html#1970">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1972">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1976">6.6</A>
 \| <A HREF="|."$dir".q|node46.html#2034">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2036">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2040">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2042">6.8.4</A>
 \| <A HREF="|."$dir".q|node46.html#2044">6.8.4</A>
 \| <A HREF="|."$dir".q|node49.html#2177">6.8.7</A>
 \| <A HREF="|."$dir".q|node49.html#2177">6.8.7</A>
 \| <A HREF="|."$dir".q|node49.html#2179">6.8.7</A>
 \| <A HREF="|."$dir".q|node49.html#2183">6.8.7</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/useradd/;
$index{$key} .= q|<A HREF="|."$dir".q|node89.html#4216">11.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tail/;
$index{$key} .= q|<A HREF="|."$dir".q|node96.html#4297">11.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bios/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3091">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/processo di boot/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#436">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/log\/messages/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1292">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/driver dei dispositivi/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#411">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/swapoff/;
$index{$key} .= q|<A HREF="|."$dir".q|node63.html#2893">7.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/login/;
$index{$key} .= q|<A HREF="|."$dir".q|node11.html#606">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#608">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#610">4.3.2</A>
 \| <A HREF="|."$dir".q|node24.html#1172">5.2.1</A>
 \| <A HREF="|."$dir".q|node27.html#1286">5.4</A>
 \| <A HREF="|."$dir".q|node81.html#3927">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3927">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3913">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3915">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3917">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3935">10.1</A>
 \| <A HREF="|."$dir".q|node83.html#3960">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3960">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3962">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3972">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3974">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3976">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/logout/;
$index{$key} .= q|<A HREF="|."$dir".q|node11.html#466">4.3.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sudo/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2127">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda1/;
$index{$key} .= q|<A HREF="|."$dir".q|node41.html#2010">6.7.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda2/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2062">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2069">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/afio/;
$index{$key} .= q|<A HREF="|."$dir".q|node106.html#4591">12.7</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/mnt\/exta/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1091">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/securetty/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1184">5.2.1</A>
 \| <A HREF="|."$dir".q|node85.html#4018">10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/restore/;
$index{$key} .= q|<A HREF="|."$dir".q|node52.html#2228">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shells/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1186">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1192">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/documentazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#405">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/inittab/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1137">5.2.1</A>
 \| <A HREF="|."$dir".q|node76.html#3619">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3619">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3623">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3629">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3633">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3635">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3651">9.2</A>
 \| <A HREF="|."$dir".q|node77.html#3670">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3680">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3688">9.3</A>
 \| <A HREF="|."$dir".q|node78.html#3690">9.4</A>
 \| <A HREF="|."$dir".q|node78.html#3690">9.4</A>
 \| <A HREF="|."$dir".q|node78.html#3692">9.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/daemoncron/;
$index{$key} .= q|<i>see </i> cron
 \| |; 
$noresave{$key} = "$nosave";

$key = q/curs_termcap/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1200">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/bin/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#668">4.4</A>
 \| <A HREF="|."$dir".q|node23.html#1059">5.2</A>
 \| <A HREF="|."$dir".q|node23.html#1063">5.2</A>
 \| <A HREF="|."$dir".q|node26.html#1236">5.3</A>
 \| <A HREF="|."$dir".q|node55.html#2240">6.10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/log/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1284">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1294">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gestione della memoria/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#410">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/modalit� multiutente/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#445">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/coda di stampa/;
$index{$key} .= q|<A HREF="|."$dir".q|node19.html#535">4.3.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/reboot/;
$index{$key} .= q|<A HREF="|."$dir".q|node71.html#3191">8.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/kernel panic/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3128">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sendmail/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#654">4.3.9</A>
 \| <A HREF="|."$dir".q|node113.html#4946">15</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#674">4.4</A>
 \| <A HREF="|."$dir".q|node23.html#1073">5.2</A>
 \| <A HREF="|."$dir".q|node25.html#1204">5.2.2</A>
 \| <A HREF="|."$dir".q|node25.html#1204">5.2.2</A>
 \| <A HREF="|."$dir".q|node25.html#1206">5.2.2</A>
 \| <A HREF="|."$dir".q|node30.html#1904">6.1</A>
 \| <A HREF="|."$dir".q|node55.html#2244">6.10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/giochi/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#406">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/localtime/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4791">13.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/now/;
$index{$key} .= q|<A HREF="|."$dir".q|node51.html#2200">6.8.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/backup/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3205">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/unmount/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2117">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#678">4.4</A>
 \| <A HREF="|."$dir".q|node22.html#1013">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1025">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1027">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1041">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1049">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1053">5.1</A>
 \| <A HREF="|."$dir".q|node23.html#1097">5.2</A>
 \| <A HREF="|."$dir".q|node27.html#1256">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1256">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1258">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1276">5.4</A>
 \| <A HREF="|."$dir".q|node47.html#2096">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdownemergenza/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3177">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/scheda video/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3111">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/kernel/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#393">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mount -a/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2139">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mbr/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3093">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/compilatore c/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#404">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/1/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1320">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/kmsg/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1340">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/netdate/;
$index{$key} .= q|<A HREF="|."$dir".q|node111.html#4827">13.4</A>
 \| <A HREF="|."$dir".q|node111.html#4829">13.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sistema x window/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#446">4.3.1</A>
 \| <A HREF="|."$dir".q|node14.html#489">4.3.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib\/zoneinfo/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4793">13.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/posta, casella/;
$index{$key} .= q|<i>see </i> posta elettronica
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#676">4.4</A>
 \| <A HREF="|."$dir".q|node22.html#1011">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1017">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1019">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1021">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1023">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1029">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1031">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1043">5.1</A>
 \| <A HREF="|."$dir".q|node23.html#1095">5.2</A>
 \| <A HREF="|."$dir".q|node26.html#1214">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1214">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1216">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1218">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1222">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1228">5.3</A>
 \| <A HREF="|."$dir".q|node47.html#2054">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2054">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2050">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2060">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2067">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2086">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2090">6.8.5</A>
 \| <A HREF="|."$dir".q|node55.html#2250">6.10.1</A>
 \| <A HREF="|."$dir".q|node55.html#2254">6.10.1</A>
 \| <A HREF="|."$dir".q|node55.html#2256">6.10.1</A>
 \| <A HREF="|."$dir".q|node55.html#2258">6.10.1</A>
 \| <A HREF="|."$dir".q|node57.html#2264">6.10.3</A>
 \| <A HREF="|."$dir".q|node57.html#2260">6.10.3</A>
 \| <A HREF="|."$dir".q|node79.html#3713">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3723">9.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/filesystem root/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3124">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#672">4.4</A>
 \| <A HREF="|."$dir".q|node23.html#1065">5.2</A>
 \| <A HREF="|."$dir".q|node24.html#1101">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1101">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1103">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1105">5.2.1</A>
 \| <A HREF="|."$dir".q|node55.html#2242">6.10.1</A>
 \| <A HREF="|."$dir".q|node105.html#4583">12.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/profile/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1178">5.2.1</A>
 \| <A HREF="|."$dir".q|node86.html#4024">10.6</A>
 \| <A HREF="|."$dir".q|node86.html#4028">10.6</A>
 \| <A HREF="|."$dir".q|node92.html#4243">11.2.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/group/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1135">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/terminali seriali/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3145">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/configurazione dei device driver/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3116">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/local/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1272">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/bin\/sh/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2123">6.8.5</A>
 \| <A HREF="|."$dir".q|node75.html#3587">9.1</A>
 \| <A HREF="|."$dir".q|node86.html#4022">10.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/booting/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3073">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/last/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3992">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/devices/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1326">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mkdir/;
$index{$key} .= q|<A HREF="|."$dir".q|node93.html#4255">11.2.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gestione dei processi/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#409">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/windows 95/;
$index{$key} .= q|<i>see </i> piangere
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/catman/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1260">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1268">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fermare il processore/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#453">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/self/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1354">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sync/;
$index{$key} .= q|<A HREF="|."$dir".q|node51.html#2192">6.8.9</A>
 \| <A HREF="|."$dir".q|node66.html#2909">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2914">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2916">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2920">7.6</A>
 \| <A HREF="|."$dir".q|node70.html#3268">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3266">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/spazio di swap/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#421">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ps/;
$index{$key} .= q|<A HREF="|."$dir".q|node65.html#2901">7.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bootdall'hard disk/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3099">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/pulizia dei file temporanei/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#479">4.3.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/dma/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1328">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tabella delle partizioni/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3101">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/crack/;
$index{$key} .= q|<A HREF="|."$dir".q|node85.html#4008">10.5</A>
 \| <A HREF="|."$dir".q|node85.html#4010">10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/termcap/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1194">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1176">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1196">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/uptime/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1362">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/umount/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2115">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2119">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2141">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/programma di sistema/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#395">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/var/;
$index{$key} .= q|<A HREF="|."$dir".q|node105.html#4579">12.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sdb7/;
$index{$key} .= q|<A HREF="|."$dir".q|node41.html#2012">6.7.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ftpd/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1190">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/crash/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3175">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fdformat/;
$index{$key} .= q|<A HREF="|."$dir".q|node35.html#1954">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1960">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1962">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1968">6.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/zip/;
$index{$key} .= q|<A HREF="|."$dir".q|node59.html#2272">6.10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/kill~-hup~1/;
$index{$key} .= q|<A HREF="|."$dir".q|node76.html#3625">9.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdowntriplo sync/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3185">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/at/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#620">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#620">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#632">4.3.4</A>
 \| <A HREF="|."$dir".q|node95.html#4285">11.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/getty/;
$index{$key} .= q|<A HREF="|."$dir".q|node11.html#464">4.3.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/skel\/.profile/;
$index{$key} .= q|<A HREF="|."$dir".q|node92.html#4237">11.2.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/version/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1364">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/modalit� utente singolo/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#444">4.3.1</A>
 \| <A HREF="|."$dir".q|node72.html#3199">8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/run/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1296">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/mtab/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1158">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/loggin/;
$index{$key} .= q|<A HREF="|."$dir".q|node11.html#465">4.3.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/log\/wtmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1288">5.4</A>
 \| <A HREF="|."$dir".q|node83.html#3988">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/syslog/;
$index{$key} .= q|<A HREF="|."$dir".q|node12.html#616">4.3.3</A>
 \| <A HREF="|."$dir".q|node27.html#1290">5.4</A>
 \| <A HREF="|."$dir".q|node35.html#1964">6.6</A>
 \| <A HREF="|."$dir".q|node83.html#3978">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/free/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1366">5.5</A>
 \| <A HREF="|."$dir".q|node63.html#2887">7.3</A>
 \| <A HREF="|."$dir".q|node63.html#2895">7.3</A>
 \| <A HREF="|."$dir".q|node65.html#2899">7.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/setfdprm/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1121">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1123">5.2.1</A>
 \| <A HREF="|."$dir".q|node32.html#1943">6.3</A>
 \| <A HREF="|."$dir".q|node32.html#1947">6.3</A>
 \| <A HREF="|."$dir".q|node35.html#1958">6.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fsck/;
$index{$key} .= q|<A HREF="|."$dir".q|node35.html#1978">6.6</A>
 \| <A HREF="|."$dir".q|node35.html#1982">6.6</A>
 \| <A HREF="|."$dir".q|node47.html#2102">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2105">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2107">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2109">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2137">6.8.5</A>
 \| <A HREF="|."$dir".q|node48.html#2149">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2149">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2151">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2153">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2155">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2161">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2169">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2171">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2175">6.8.6</A>
 \| <A HREF="|."$dir".q|node49.html#2181">6.8.7</A>
 \| <A HREF="|."$dir".q|node52.html#2222">6.8.10</A>
 \| <A HREF="|."$dir".q|node69.html#3132">8.2</A>
 \| <A HREF="|."$dir".q|node79.html#3711">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3721">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3725">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3729">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3731">9.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tune2fs/;
$index{$key} .= q|<A HREF="|."$dir".q|node52.html#2208">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2214">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/wtmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3994">10.3</A>
 \| <A HREF="|."$dir".q|node83.html#3998">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mke2fs/;
$index{$key} .= q|<A HREF="|."$dir".q|node52.html#2204">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/drive del floppy/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3203">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/dischetti di installazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3206">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/panic/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3129">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/getty/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#594">4.3.1</A>
 \| <A HREF="|."$dir".q|node11.html#598">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#602">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#604">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#614">4.3.2</A>
 \| <A HREF="|."$dir".q|node16.html#636">4.3.7</A>
 \| <A HREF="|."$dir".q|node16.html#642">4.3.7</A>
 \| <A HREF="|."$dir".q|node16.html#648">4.3.7</A>
 \| <A HREF="|."$dir".q|node24.html#1143">5.2.1</A>
 \| <A HREF="|."$dir".q|node69.html#3248">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3250">8.2</A>
 \| <A HREF="|."$dir".q|node74.html#3565">9</A>
 \| <A HREF="|."$dir".q|node75.html#3593">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3597">9.1</A>
 \| <A HREF="|."$dir".q|node76.html#3617">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3617">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3649">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3631">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3637">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3641">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3647">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3657">9.2</A>
 \| <A HREF="|."$dir".q|node81.html#3925">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3925">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3905">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3907">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3909">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3921">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3933">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3939">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3941">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3945">10.1</A>
 \| <A HREF="|."$dir".q|node82.html#3950">10.2</A>
 \| <A HREF="|."$dir".q|node82.html#3952">10.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/update/;
$index{$key} .= q|<A HREF="|."$dir".q|node66.html#2928">7.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/time/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4799">13.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/controllo di un filesystem/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3131">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/athena/;
$index{$key} .= q|<A HREF="|."$dir".q|node14.html#490">4.3.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/casella di posta in arrivo/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#522">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/comunicazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#515">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/lseek/;
$index{$key} .= q|<A HREF="|."$dir".q|node43.html#2022">6.8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/vigr/;
$index{$key} .= q|<A HREF="|."$dir".q|node93.html#4253">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4281">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/telinit/;
$index{$key} .= q|<A HREF="|."$dir".q|node77.html#3684">9.3</A>
 \| <A HREF="|."$dir".q|node79.html#3715">9.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenzauso/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3207">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdown improprio/;
$index{$key} .= q|<i>see </i> shutdown, emergenza
 \| |; 
$noresave{$key} = "$nosave";

$key = q/master boot record/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3092">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/man/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1266">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man\/cat*/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1264">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/lib/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#670">4.4</A>
 \| <A HREF="|."$dir".q|node23.html#1069">5.2</A>
 \| <A HREF="|."$dir".q|node55.html#2246">6.10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/chsh/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1188">5.2.1</A>
 \| <A HREF="|."$dir".q|node94.html#4269">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/open look/;
$index{$key} .= q|<A HREF="|."$dir".q|node14.html#492">4.3.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/daemoninit/;
$index{$key} .= q|<i>see </i> /sbin/init
 \| |; 
$noresave{$key} = "$nosave";

$key = q/filesystemroot/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3125">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/daemonat/;
$index{$key} .= q|<i>see </i> at
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda/;
$index{$key} .= q|<A HREF="|."$dir".q|node31.html#1925">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/bootdal floppy di emergenza/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3202">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdb/;
$index{$key} .= q|<A HREF="|."$dir".q|node31.html#1927">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/messaggi di errore/;
$index{$key} .= q|<A HREF="|."$dir".q|node12.html#470">4.3.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdc/;
$index{$key} .= q|<A HREF="|."$dir".q|node31.html#1929">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdd/;
$index{$key} .= q|<A HREF="|."$dir".q|node31.html#1931">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/doc/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1246">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sistema operativo/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#394">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/xterm/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3258">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/modalit� testuale/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3114">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fdisk/;
$index{$key} .= q|<A HREF="|."$dir".q|node37.html#1987">6.7.1</A>
 \| <A HREF="|."$dir".q|node39.html#1996">6.7.3</A>
 \| <A HREF="|."$dir".q|node39.html#1996">6.7.3</A>
 \| <A HREF="|."$dir".q|node39.html#1994">6.7.3</A>
 \| <A HREF="|."$dir".q|node40.html#1998">6.7.4</A>
 \| <A HREF="|."$dir".q|node40.html#2000">6.7.4</A>
 \| <A HREF="|."$dir".q|node40.html#2004">6.7.4</A>
 \| <A HREF="|."$dir".q|node40.html#2006">6.7.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/processi in backgrounde spegnimento del computer/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3152">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cron/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#618">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#618">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#626">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#630">4.3.4</A>
 \| <A HREF="|."$dir".q|node13.html#634">4.3.4</A>
 \| <A HREF="|."$dir".q|node83.html#3990">10.3</A>
 \| <A HREF="|."$dir".q|node95.html#4283">11.4</A>
 \| <A HREF="|."$dir".q|node110.html#4815">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4817">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4819">13.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/interrupts/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1332">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/makedev.local/;
$index{$key} .= q|<A HREF="|."$dir".q|node25.html#1210">5.2.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mkswap/;
$index{$key} .= q|<A HREF="|."$dir".q|node62.html#2868">7.2</A>
 \| <A HREF="|."$dir".q|node62.html#2873">7.2</A>
 \| <A HREF="|."$dir".q|node62.html#2875">7.2</A>
 \| <A HREF="|."$dir".q|node62.html#2877">7.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tolleranza degli errori/;
$index{$key} .= q|<A HREF="|."$dir".q|node15.html#496">4.3.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/filesystem root a sola lettura/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3130">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shadow.group/;
$index{$key} .= q|<A HREF="|."$dir".q|node85.html#4016">10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/include/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1248">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/chown/;
$index{$key} .= q|<A HREF="|."$dir".q|node93.html#4259">11.2.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/messaggio/;
$index{$key} .= q|<i>see </i> posta elettronica
 \| |; 
$noresave{$key} = "$nosave";

$key = q/terminale/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3144">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/driver dei filesystem/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#412">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/user mode/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#400">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/su/;
$index{$key} .= q|<A HREF="|."$dir".q|node85.html#4020">10.5</A>
 \| <A HREF="|."$dir".q|node96.html#4299">11.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/messaggio di shutdown/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3169">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/dd/;
$index{$key} .= q|<A HREF="|."$dir".q|node53.html#2234">6.9</A>
 \| <A HREF="|."$dir".q|node53.html#2236">6.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/demonitelnet/;
$index{$key} .= q|<i>see </i> telnet
 \| |; 
$noresave{$key} = "$nosave";

$key = q/avvio del computer/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3074">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/df/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1162">5.2.1</A>
 \| <A HREF="|."$dir".q|node51.html#2188">6.8.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gcc/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#402">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/spool/;
$index{$key} .= q|<A HREF="|."$dir".q|node19.html#539">4.3.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/stat/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1360">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/rdate/;
$index{$key} .= q|<A HREF="|."$dir".q|node111.html#4825">13.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gestione della rete/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#413">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fstab/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2113">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mount/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1129">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1160">5.2.1</A>
 \| <A HREF="|."$dir".q|node47.html#2056">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2074">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2076">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2147">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/du/;
$index{$key} .= q|<A HREF="|."$dir".q|node51.html#2190">6.8.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/tzset/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4795">13.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/home\/staff/;
$index{$key} .= q|<A HREF="|."$dir".q|node22.html#1039">5.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/interfaccia grafica utente/;
$index{$key} .= q|<A HREF="|."$dir".q|node14.html#488">4.3.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdown/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3254">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3256">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3159">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3270">8.3</A>
 \| <A HREF="|."$dir".q|node71.html#3272">8.4</A>
 \| <A HREF="|."$dir".q|node72.html#3274">8.5</A>
 \| <A HREF="|."$dir".q|node83.html#3970">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/autenticazione degli utenti/;
$index{$key} .= q|<A HREF="|."$dir".q|node11.html#467">4.3.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/modalit� video/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3113">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/login.defs/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1170">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/info/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1244">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mount di filesystem/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#435">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/cpuinfo/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1324">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenzacreazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3210">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/group/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1131">5.2.1</A>
 \| <A HREF="|."$dir".q|node85.html#4014">10.5</A>
 \| <A HREF="|."$dir".q|node93.html#4251">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4279">11.3</A>
 \| <A HREF="|."$dir".q|node95.html#4289">11.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/demonirlogin/;
$index{$key} .= q|<i>see </i> rlogin
 \| |; 
$noresave{$key} = "$nosave";

$key = q/adduser/;
$index{$key} .= q|<A HREF="|."$dir".q|node89.html#4214">11.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/filesystem virtuale/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#425">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fdprm/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1119">5.2.1</A>
 \| <A HREF="|."$dir".q|node32.html#1945">6.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cfdisk/;
$index{$key} .= q|<A HREF="|."$dir".q|node40.html#2002">6.7.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/userdel/;
$index{$key} .= q|<A HREF="|."$dir".q|node95.html#4295">11.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/x11r6/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1224">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1226">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1232">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/chfn/;
$index{$key} .= q|<A HREF="|."$dir".q|node94.html#4267">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shadow/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1164">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1168">5.2.1</A>
 \| <A HREF="|."$dir".q|node85.html#4006">10.5</A>
 \| <A HREF="|."$dir".q|node90.html#4226">11.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/syslogd/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1342">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/linux filesystem standard/;
$index{$key} .= q|<i>see </i> FSSTND
 \| |; 
$noresave{$key} = "$nosave";

$key = q/nfs/;
$index{$key} .= q|<A HREF="|."$dir".q|node17.html#511">4.3.8</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/casella di posta/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#520">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/skel/;
$index{$key} .= q|<A HREF="|."$dir".q|node92.html#4231">11.2.3</A>
 \| <A HREF="|."$dir".q|node92.html#4231">11.2.3</A>
 \| <A HREF="|."$dir".q|node92.html#4233">11.2.3</A>
 \| <A HREF="|."$dir".q|node92.html#4235">11.2.3</A>
 \| <A HREF="|."$dir".q|node92.html#4239">11.2.3</A>
 \| <A HREF="|."$dir".q|node93.html#4257">11.2.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/filesystems/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1330">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/inittab/;
$index{$key} .= q|<A HREF="|."$dir".q|node76.html#3655">9.2</A>
 \| <A HREF="|."$dir".q|node78.html#3706">9.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/vfs/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#426">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/initmodalit� utente singolo/;
$index{$key} .= q|<A HREF="|."$dir".q|node72.html#3200">8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/informatica distribuita/;
$index{$key} .= q|<A HREF="|."$dir".q|node15.html#495">4.3.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/esecuzione periodica di comandi/;
$index{$key} .= q|<i>see </i> cron e at
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/spool/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1300">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1302">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cache/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3150">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/crash di sistema/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3176">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/inetd/;
$index{$key} .= q|<A HREF="|."$dir".q|node82.html#3958">10.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/uccisione di processi/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#451">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/perdita dei dati/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3083">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/spegnere il computer/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3148">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/mtools/;
$index{$key} .= q|<A HREF="|."$dir".q|node47.html#2129">6.8.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/inite ctrl-alt-del/;
$index{$key} .= q|<A HREF="|."$dir".q|node71.html#3194">8.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/file/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1147">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1149">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1153">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/messaggi di avvio/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3117">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gzexe/;
$index{$key} .= q|<A HREF="|."$dir".q|node59.html#2274">6.10.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/local/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1254">5.3</A>
 \| <A HREF="|."$dir".q|node26.html#1220">5.3</A>
 \| <A HREF="|."$dir".q|node27.html#1274">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/dumpe2fs/;
$index{$key} .= q|<A HREF="|."$dir".q|node52.html#2218">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2218">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2216">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/spool\/mail/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#664">4.3.9</A>
 \| <A HREF="|."$dir".q|node27.html#1304">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/settore di boot/;
$index{$key} .= q|<A HREF="|."$dir".q|node68.html#3079">8.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/condivisione di stampanti/;
$index{$key} .= q|<A HREF="|."$dir".q|node19.html#536">4.3.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/informatica centralizzata/;
$index{$key} .= q|<A HREF="|."$dir".q|node15.html#494">4.3.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/modules/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1350">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/ramdisk/;
$index{$key} .= q|<A HREF="|."$dir".q|node73.html#3211">8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/chmod/;
$index{$key} .= q|<A HREF="|."$dir".q|node93.html#4261">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4273">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/pine/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#660">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/passwd/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1115">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1133">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1166">5.2.1</A>
 \| <A HREF="|."$dir".q|node79.html#3733">9.5</A>
 \| <A HREF="|."$dir".q|node85.html#4003">10.5</A>
 \| <A HREF="|."$dir".q|node90.html#4218">11.2.1</A>
 \| <A HREF="|."$dir".q|node90.html#4218">11.2.1</A>
 \| <A HREF="|."$dir".q|node90.html#4220">11.2.1</A>
 \| <A HREF="|."$dir".q|node90.html#4228">11.2.1</A>
 \| <A HREF="|."$dir".q|node93.html#4245">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4265">11.3</A>
 \| <A HREF="|."$dir".q|node94.html#4275">11.3</A>
 \| <A HREF="|."$dir".q|node95.html#4287">11.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/runlevel/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#443">4.3.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/partizione attiva/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3102">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/lock/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1280">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1278">5.4</A>
 \| <A HREF="|."$dir".q|node27.html#1282">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fsstnd/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#549">4.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1242">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/init/;
$index{$key} .= q|<A HREF="|."$dir".q|node10.html#575">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#575">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#577">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#579">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#581">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#583">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#585">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#592">4.3.1</A>
 \| <A HREF="|."$dir".q|node10.html#596">4.3.1</A>
 \| <A HREF="|."$dir".q|node11.html#600">4.3.2</A>
 \| <A HREF="|."$dir".q|node11.html#612">4.3.2</A>
 \| <A HREF="|."$dir".q|node24.html#1113">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1139">5.2.1</A>
 \| <A HREF="|."$dir".q|node68.html#3226">8.1</A>
 \| <A HREF="|."$dir".q|node68.html#3228">8.1</A>
 \| <A HREF="|."$dir".q|node69.html#3240">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3244">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3246">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3252">8.2</A>
 \| <A HREF="|."$dir".q|node70.html#3260">8.3</A>
 \| <A HREF="|."$dir".q|node74.html#3559">9</A>
 \| <A HREF="|."$dir".q|node74.html#3559">9</A>
 \| <A HREF="|."$dir".q|node74.html#3561">9</A>
 \| <A HREF="|."$dir".q|node74.html#3563">9</A>
 \| <A HREF="|."$dir".q|node74.html#3567">9</A>
 \| <i>see </i> /sbin/init
 \| <A HREF="|."$dir".q|node75.html#3569">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3569">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3603">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3571">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3573">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3575">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3577">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3579">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3581">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3585">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3589">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3595">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3599">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3601">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3605">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3609">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3611">9.1</A>
 \| <A HREF="|."$dir".q|node76.html#3615">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3615">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3621">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3627">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3653">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3659">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3661">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3663">9.2</A>
 \| <A HREF="|."$dir".q|node76.html#3665">9.2</A>
 \| <A HREF="|."$dir".q|node77.html#3668">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3672">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3674">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3678">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3682">9.3</A>
 \| <A HREF="|."$dir".q|node77.html#3686">9.3</A>
 \| <A HREF="|."$dir".q|node78.html#3694">9.4</A>
 \| <A HREF="|."$dir".q|node78.html#3696">9.4</A>
 \| <A HREF="|."$dir".q|node78.html#3698">9.4</A>
 \| <A HREF="|."$dir".q|node78.html#3700">9.4</A>
 \| <A HREF="|."$dir".q|node79.html#3717">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3719">9.5</A>
 \| <A HREF="|."$dir".q|node79.html#3727">9.5</A>
 \| <A HREF="|."$dir".q|node81.html#3923">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3923">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3903">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3919">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3929">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3943">10.1</A>
 \| <A HREF="|."$dir".q|node81.html#3947">10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/file temporanei/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#478">4.3.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/shutdownazioni di/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3172">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/filesystem standard/;
$index{$key} .= q|<i>see </i> FSSTND
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/home/;
$index{$key} .= q|<A HREF="|."$dir".q|node20.html#680">4.4</A>
 \| <A HREF="|."$dir".q|node22.html#1015">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1033">5.1</A>
 \| <A HREF="|."$dir".q|node22.html#1035">5.1</A>
 \| <A HREF="|."$dir".q|node23.html#1099">5.2</A>
 \| <A HREF="|."$dir".q|node47.html#2052">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2052">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2048">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2058">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2065">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2071">6.8.5</A>
 \| <A HREF="|."$dir".q|node55.html#2252">6.10.1</A>
 \| <A HREF="|."$dir".q|node57.html#2266">6.10.3</A>
 \| <A HREF="|."$dir".q|node57.html#2262">6.10.3</A>
 \| <A HREF="|."$dir".q|node105.html#4581">12.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/extra-swap/;
$index{$key} .= q|<A HREF="|."$dir".q|node62.html#2870">7.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/e2fsck/;
$index{$key} .= q|<A HREF="|."$dir".q|node48.html#2159">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2165">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2167">6.8.6</A>
 \| <A HREF="|."$dir".q|node49.html#2185">6.8.7</A>
 \| <A HREF="|."$dir".q|node52.html#2206">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2210">6.8.10</A>
 \| <A HREF="|."$dir".q|node52.html#2212">6.8.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/console virtuale/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3142">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/tmp/;
$index{$key} .= q|<A HREF="|."$dir".q|node13.html#622">4.3.4</A>
 \| <A HREF="|."$dir".q|node23.html#1075">5.2</A>
 \| <A HREF="|."$dir".q|node23.html#1079">5.2</A>
 \| <A HREF="|."$dir".q|node27.html#1308">5.4</A>
 \| <A HREF="|."$dir".q|node47.html#2078">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2082">6.8.5</A>
 \| <A HREF="|."$dir".q|node55.html#2248">6.10.1</A>
 \| <A HREF="|."$dir".q|node75.html#3591">9.1</A>
 \| <A HREF="|."$dir".q|node78.html#3704">9.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/magic/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1151">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/boot/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1081">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1093">5.2</A>
 \| <A HREF="|."$dir".q|node28.html#1312">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1312">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1314">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1316">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1322">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1338">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1356">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1358">5.5</A>
 \| <A HREF="|."$dir".q|node44.html#2024">6.8.2</A>
 \| <A HREF="|."$dir".q|node105.html#4575">12.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/issue/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1141">5.2.1</A>
 \| <A HREF="|."$dir".q|node81.html#3911">10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/sysvinit/;
$index{$key} .= q|<A HREF="|."$dir".q|node75.html#3607">9.1</A>
 \| <A HREF="|."$dir".q|node75.html#3613">9.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/piangere/;
$index{$key} .= q|<A HREF="|."$dir".q|node67.html#3068">8</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/local\/bin/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1238">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/termcap/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1198">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/montarefilesystem di root/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3126">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/file di log/;
$index{$key} .= q|<A HREF="|."$dir".q|node12.html#472">4.3.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/passwd/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1117">5.2.1</A>
 \| <A HREF="|."$dir".q|node85.html#4012">10.5</A>
 \| <A HREF="|."$dir".q|node90.html#4223">11.2.1</A>
 \| <A HREF="|."$dir".q|node93.html#4263">11.2.4</A>
 \| <A HREF="|."$dir".q|node94.html#4271">11.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/root/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1067">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/mnt\/dosa/;
$index{$key} .= q|<A HREF="|."$dir".q|node23.html#1089">5.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/smail/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#656">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/configurazione del kernel/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3112">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/chiamata di sistema/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#397">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/multitasking/;
$index{$key} .= q|<A HREF="|."$dir".q|node8.html#423">4.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/var\/lib/;
$index{$key} .= q|<A HREF="|."$dir".q|node27.html#1270">5.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/linguaggio di programmazione/;
$index{$key} .= q|<A HREF="|."$dir".q|node7.html#403">4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/date/;
$index{$key} .= q|<A HREF="|."$dir".q|node110.html#4797">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4801">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4803">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4805">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4807">13.3</A>
 \| <A HREF="|."$dir".q|node110.html#4811">13.3</A>
 \| <A HREF="|."$dir".q|node111.html#4821">13.4</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/.hushlogin/;
$index{$key} .= q|<A HREF="|."$dir".q|node83.html#3966">10.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc?.d/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1111">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/find/;
$index{$key} .= q|<A HREF="|."$dir".q|node95.html#4291">11.4</A>
 \| <A HREF="|."$dir".q|node102.html#4556">12.4.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/ioports/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1334">5.5</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/update/;
$index{$key} .= q|<A HREF="|."$dir".q|node51.html#2194">6.8.9</A>
 \| <A HREF="|."$dir".q|node51.html#2196">6.8.9</A>
 \| <A HREF="|."$dir".q|node51.html#2202">6.8.9</A>
 \| <A HREF="|."$dir".q|node66.html#2912">7.6</A>
 \| <A HREF="|."$dir".q|node66.html#2924">7.6</A>
 \| <A HREF="|."$dir".q|node70.html#3262">8.3</A>
 \| <A HREF="|."$dir".q|node70.html#3264">8.3</A>
 \| <A HREF="|."$dir".q|node113.html#4944">15</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/init.d\/rc/;
$index{$key} .= q|<A HREF="|."$dir".q|node77.html#3676">9.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd0h1440/;
$index{$key} .= q|<A HREF="|."$dir".q|node32.html#1937">6.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fdisk -l/;
$index{$key} .= q|<A HREF="|."$dir".q|node37.html#1989">6.7.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fstab/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1125">5.2.1</A>
 \| <A HREF="|."$dir".q|node47.html#2111">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2131">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2133">6.8.5</A>
 \| <A HREF="|."$dir".q|node47.html#2143">6.8.5</A>
 \| <A HREF="|."$dir".q|node58.html#2268">6.10.4</A>
 \| <A HREF="|."$dir".q|node63.html#2881">7.3</A>
 \| <A HREF="|."$dir".q|node63.html#2883">7.3</A>
 \| <A HREF="|."$dir".q|node63.html#2897">7.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cpio/;
$index{$key} .= q|<A HREF="|."$dir".q|node100.html#4508">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4514">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4518">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4524">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4528">12.3</A>
 \| <A HREF="|."$dir".q|node100.html#4536">12.3</A>
 \| <A HREF="|."$dir".q|node104.html#4573">12.5</A>
 \| <A HREF="|."$dir".q|node106.html#4593">12.7</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/network file system/;
$index{$key} .= q|<i>see </i> NFS
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1107">5.2.1</A>
 \| <A HREF="|."$dir".q|node24.html#1127">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/lilo/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3103">8.2</A>
 \| <A HREF="|."$dir".q|node69.html#3127">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/bin/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1234">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/usr\/x386/;
$index{$key} .= q|<A HREF="|."$dir".q|node26.html#1230">5.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/relazioni sociali/;
$index{$key} .= q|<A HREF="|."$dir".q|node19.html#537">4.3.10</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/floppybooting da/;
$index{$key} .= q|<i>see </i> booting
 \| |; 
$noresave{$key} = "$nosave";

$key = q/fork/;
$index{$key} .= q|<A HREF="|."$dir".q|node81.html#3931">10.1</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/console/;
$index{$key} .= q|<A HREF="|."$dir".q|node69.html#3143">8.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sda/;
$index{$key} .= q|<A HREF="|."$dir".q|node30.html#1912">6.1</A>
 \| <A HREF="|."$dir".q|node31.html#1933">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sdb/;
$index{$key} .= q|<A HREF="|."$dir".q|node31.html#1935">6.2</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/boot recordpartizione/;
$index{$key} .= q|<i>see </i> boot record della partizione
 \| |; 
$noresave{$key} = "$nosave";

$key = q/gzip/;
$index{$key} .= q|<A HREF="|."$dir".q|node59.html#2270">6.10.5</A>
 \| <A HREF="|."$dir".q|node106.html#4587">12.7</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/cache del disco/;
$index{$key} .= q|<A HREF="|."$dir".q|node70.html#3151">8.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fastboot/;
$index{$key} .= q|<A HREF="|."$dir".q|node48.html#2157">6.8.6</A>
 \| <A HREF="|."$dir".q|node48.html#2163">6.8.6</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/proc\/meminfo/;
$index{$key} .= q|<A HREF="|."$dir".q|node28.html#1348">5.5</A>
 \| <A HREF="|."$dir".q|node28.html#1368">5.5</A>
 \| <A HREF="|."$dir".q|node63.html#2891">7.3</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/elm/;
$index{$key} .= q|<A HREF="|."$dir".q|node18.html#662">4.3.9</A>
 \| |; 
$noresave{$key} = "$nosave";

$key = q/\/etc\/csh.login/;
$index{$key} .= q|<A HREF="|."$dir".q|node24.html#1180">5.2.1</A>
 \| |; 
$noresave{$key} = "$nosave";

# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Printable index-keys from sub_index array.


$key = q/booting/;
$sub_index{$key} .= q|bootingda floppy|; 
$noresave{$key} = "$nosave";

$key = q/boot record/;
$sub_index{$key} .= q|boot recordmasterboot recordpartizione|; 
$noresave{$key} = "$nosave";

$key = q/daemon/;
$sub_index{$key} .= q|daemoncrondaemonatdaemoninit|; 
$noresave{$key} = "$nosave";

$key = q/boot/;
$sub_index{$key} .= q|bootdall'hard diskbootmessaggibootdal floppy di emergenza|; 
$noresave{$key} = "$nosave";

$key = q/init/;
$sub_index{$key} .= q|inite ctrl-alt-delinitmodalit� utente singolo|; 
$noresave{$key} = "$nosave";

$key = q/filesystem/;
$sub_index{$key} .= q|filesystemroot|; 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenza/;
$sub_index{$key} .= q|floppy di emergenzausofloppy di emergenzacreazione|; 
$noresave{$key} = "$nosave";

$key = q/montare/;
$sub_index{$key} .= q|montarefilesystem di root|; 
$noresave{$key} = "$nosave";

$key = q/hard disk/;
$sub_index{$key} .= q|hard diskboot da|; 
$noresave{$key} = "$nosave";

$key = q/floppy/;
$sub_index{$key} .= q|floppybooting da|; 
$noresave{$key} = "$nosave";

$key = q/demoni/;
$sub_index{$key} .= q|demonitelnetdemonirlogindemoniinizializzazione|; 
$noresave{$key} = "$nosave";

$key = q/shutdown/;
$sub_index{$key} .= q|shutdownusandoshutdownazioni dishutdownemergenzashutdowntriplo sync|; 
$noresave{$key} = "$nosave";

$key = q/processi in background/;
$sub_index{$key} .= q|processi in backgrounde spegnimento del computer|; 
$noresave{$key} = "$nosave";

# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Printable index-keys from printable_key array.


$key = q/messaggi di avvertimento/;
$printable_key{$key} = q|messaggi di avvertimento| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/home\/students/;
$printable_key{$key} = q|/home/students| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/var/;
$printable_key{$key} = q|/usr/var| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc.d/;
$printable_key{$key} = q|/etc/rc.d| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/terminfo/;
$printable_key{$key} = q|terminfo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ctrl-alt-del/;
$printable_key{$key} = q|ctrl-alt-del| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bdflush/;
$printable_key{$key} = q|bdflush| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/unmount di filesystem/;
$printable_key{$key} = q|unmount di filesystem| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/lib\/modules/;
$printable_key{$key} = q|/lib/modules| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/who/;
$printable_key{$key} = q|who| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/demoniinizializzazione/;
$printable_key{$key} = q|inizializzazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/rdev/;
$printable_key{$key} = q|rdev| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/adm\/messages/;
$printable_key{$key} = q|/usr/adm/messages| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mkfs/;
$printable_key{$key} = q|mkfs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/boot/;
$printable_key{$key} = q|boot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/proc/;
$printable_key{$key} = q|proc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/e-mail/;
$printable_key{$key} = q|e-mail| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dump/;
$printable_key{$key} = q|dump| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bsd/;
$printable_key{$key} = q|BSD| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cache di buffer/;
$printable_key{$key} = q|cache di buffer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/sbin/;
$printable_key{$key} = q|/sbin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/mnt/;
$printable_key{$key} = q|/mnt| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/nethack/;
$printable_key{$key} = q|nethack| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/modalit� utente/;
$printable_key{$key} = q|modalit� utente| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/.profile/;
$printable_key{$key} = q|.profile| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/umask/;
$printable_key{$key} = q|umask| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/posta elettronica/;
$printable_key{$key} = q|posta elettronica| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/root/;
$printable_key{$key} = q|root| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/exec/;
$printable_key{$key} = q|exec| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdownusando/;
$printable_key{$key} = q|usando| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man\/man*/;
$printable_key{$key} = q|/usr/man/man*| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/telnet/;
$printable_key{$key} = q|telnet| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/clock/;
$printable_key{$key} = q|clock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/compressione del kernel/;
$printable_key{$key} = q|compressione del kernel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/motd/;
$printable_key{$key} = q|/etc/motd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fips/;
$printable_key{$key} = q|fips| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bootingda floppy/;
$printable_key{$key} = q|da floppy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/top/;
$printable_key{$key} = q|top| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bootstrap loader/;
$printable_key{$key} = q|bootstrap loader| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/swapon/;
$printable_key{$key} = q|swapon| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/makedev/;
$printable_key{$key} = q|/dev/MAKEDEV| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/printcap/;
$printable_key{$key} = q|/etc/printcap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/makedev/;
$printable_key{$key} = q|MAKEDEV| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/hard diskboot da/;
$printable_key{$key} = q|boot da| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/vipw/;
$printable_key{$key} = q|vipw| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/utmp/;
$printable_key{$key} = q|utmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/kcore/;
$printable_key{$key} = q|/proc/kcore| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/ksyms/;
$printable_key{$key} = q|/proc/ksyms| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/crontab/;
$printable_key{$key} = q|crontab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppy-image/;
$printable_key{$key} = q|floppy-image| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/rlogin/;
$printable_key{$key} = q|rlogin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/lpr/;
$printable_key{$key} = q|lpr| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/tty1/;
$printable_key{$key} = q|/dev/tty1| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/loadavg/;
$printable_key{$key} = q|/proc/loadavg| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/deluser/;
$printable_key{$key} = q|deluser| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/accetta/;
$printable_key{$key} = q|accetta| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ls -l/;
$printable_key{$key} = q|ls -l| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/csh.cshrc/;
$printable_key{$key} = q|/etc/csh.cshrc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/boot record della partizione/;
$printable_key{$key} = q|boot record della partizione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/double/;
$printable_key{$key} = q|DouBle| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/magic/;
$printable_key{$key} = q|/etc/magic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/tty/;
$printable_key{$key} = q|/dev/tty| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/accendere il computer/;
$printable_key{$key} = q|accendere il computer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/init/;
$printable_key{$key} = q|/sbin/init| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ls/;
$printable_key{$key} = q|ls| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/motif/;
$printable_key{$key} = q|Motif| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/adm\/messages/;
$printable_key{$key} = q|/var/adm/messages| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/debugfs/;
$printable_key{$key} = q|debugfs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/boot recordmaster/;
$printable_key{$key} = q|master| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file system di rete/;
$printable_key{$key} = q|file system di rete| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bootmessaggi/;
$printable_key{$key} = q|messaggi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib\/libc.a/;
$printable_key{$key} = q|/usr/lib/libc.a| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tar/;
$printable_key{$key} = q|tar| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/socket/;
$printable_key{$key} = q|socket| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/hard disk/;
$printable_key{$key} = q|hard disk| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib/;
$printable_key{$key} = q|/usr/lib| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/nologin/;
$printable_key{$key} = q|/etc/nologin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/run\/utmp/;
$printable_key{$key} = q|/var/run/utmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/daemon/;
$printable_key{$key} = q|daemon| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd0/;
$printable_key{$key} = q|/dev/fd0| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/w/;
$printable_key{$key} = q|w| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/tmp/;
$printable_key{$key} = q|/var/tmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd1/;
$printable_key{$key} = q|/dev/fd1| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/net/;
$printable_key{$key} = q|/proc/net| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/configurazione dell'hardware/;
$printable_key{$key} = q|configurazione dell'hardware| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/programma applicativo/;
$printable_key{$key} = q|programma applicativo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/sbin/;
$printable_key{$key} = q|/usr/sbin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/vmlinuz/;
$printable_key{$key} = q|/vmlinuz| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/badblocks/;
$printable_key{$key} = q|badblocks| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/useradd/;
$printable_key{$key} = q|useradd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tail/;
$printable_key{$key} = q|tail| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bios/;
$printable_key{$key} = q|BIOS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/processo di boot/;
$printable_key{$key} = q|processo di boot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/log\/messages/;
$printable_key{$key} = q|/var/log/messages| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/driver dei dispositivi/;
$printable_key{$key} = q|driver dei dispositivi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/swapoff/;
$printable_key{$key} = q|swapoff| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/login/;
$printable_key{$key} = q|login| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/logout/;
$printable_key{$key} = q|logout| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sudo/;
$printable_key{$key} = q|sudo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda1/;
$printable_key{$key} = q|/dev/hda1| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda2/;
$printable_key{$key} = q|/dev/hda2| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/afio/;
$printable_key{$key} = q|afio| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/mnt\/exta/;
$printable_key{$key} = q|/mnt/exta| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/securetty/;
$printable_key{$key} = q|/etc/securetty| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/restore/;
$printable_key{$key} = q|restore| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shells/;
$printable_key{$key} = q|/etc/shells| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/documentazione/;
$printable_key{$key} = q|documentazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/inittab/;
$printable_key{$key} = q|/etc/inittab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/daemoncron/;
$printable_key{$key} = q|cron| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/curs_termcap/;
$printable_key{$key} = q|curs_termcap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/bin/;
$printable_key{$key} = q|/bin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/log/;
$printable_key{$key} = q|/var/log| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gestione della memoria/;
$printable_key{$key} = q|gestione della memoria| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/modalit� multiutente/;
$printable_key{$key} = q|modalit� multiutente| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/coda di stampa/;
$printable_key{$key} = q|coda di stampa| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/reboot/;
$printable_key{$key} = q|reboot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/kernel panic/;
$printable_key{$key} = q|kernel panic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sendmail/;
$printable_key{$key} = q|sendmail| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev/;
$printable_key{$key} = q|/dev| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/giochi/;
$printable_key{$key} = q|giochi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/localtime/;
$printable_key{$key} = q|/etc/localtime| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/now/;
$printable_key{$key} = q|now| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/backup/;
$printable_key{$key} = q|backup| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/unmount/;
$printable_key{$key} = q|unmount| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var/;
$printable_key{$key} = q|/var| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdownemergenza/;
$printable_key{$key} = q|emergenza| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/scheda video/;
$printable_key{$key} = q|scheda video| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/kernel/;
$printable_key{$key} = q|kernel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mount -a/;
$printable_key{$key} = q|mount -a| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mbr/;
$printable_key{$key} = q|MBR| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/compilatore c/;
$printable_key{$key} = q|compilatore C| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/1/;
$printable_key{$key} = q|/proc/1| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/kmsg/;
$printable_key{$key} = q|/proc/kmsg| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/netdate/;
$printable_key{$key} = q|netdate| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sistema x window/;
$printable_key{$key} = q|Sistema X Window| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/lib\/zoneinfo/;
$printable_key{$key} = q|/usr/lib/zoneinfo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/posta, casella/;
$printable_key{$key} = q|posta, casella| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr/;
$printable_key{$key} = q|/usr| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystem root/;
$printable_key{$key} = q|filesystem root| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc/;
$printable_key{$key} = q|/etc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/profile/;
$printable_key{$key} = q|/etc/profile| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/group/;
$printable_key{$key} = q|group| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/terminali seriali/;
$printable_key{$key} = q|terminali seriali| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/configurazione dei device driver/;
$printable_key{$key} = q|configurazione dei device driver| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/local/;
$printable_key{$key} = q|/var/local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/bin\/sh/;
$printable_key{$key} = q|/bin/sh| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/booting/;
$printable_key{$key} = q|booting| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/last/;
$printable_key{$key} = q|last| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/devices/;
$printable_key{$key} = q|/proc/devices| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mkdir/;
$printable_key{$key} = q|mkdir| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gestione dei processi/;
$printable_key{$key} = q|gestione dei processi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/windows 95/;
$printable_key{$key} = q|Windows 95| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/catman/;
$printable_key{$key} = q|/var/catman| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fermare il processore/;
$printable_key{$key} = q|fermare il processore| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/self/;
$printable_key{$key} = q|/proc/self| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sync/;
$printable_key{$key} = q|sync| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/spazio di swap/;
$printable_key{$key} = q|spazio di swap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/processi in background/;
$printable_key{$key} = q|processi in background| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ps/;
$printable_key{$key} = q|ps| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bootdall'hard disk/;
$printable_key{$key} = q|dall'hard disk| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pulizia dei file temporanei/;
$printable_key{$key} = q|pulizia dei file temporanei| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/dma/;
$printable_key{$key} = q|/proc/dma| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tabella delle partizioni/;
$printable_key{$key} = q|tabella delle partizioni| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/crack/;
$printable_key{$key} = q|crack| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/termcap/;
$printable_key{$key} = q|/etc/termcap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/uptime/;
$printable_key{$key} = q|/proc/uptime| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/umount/;
$printable_key{$key} = q|umount| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/programma di sistema/;
$printable_key{$key} = q|programma di sistema| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/var/;
$printable_key{$key} = q|var| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sdb7/;
$printable_key{$key} = q|/dev/sdb7| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ftpd/;
$printable_key{$key} = q|ftpd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/crash/;
$printable_key{$key} = q|crash| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fdformat/;
$printable_key{$key} = q|fdformat| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/zip/;
$printable_key{$key} = q|zip| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/kill~-hup~1/;
$printable_key{$key} = q|kill~-HUP~1| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdowntriplo sync/;
$printable_key{$key} = q|triplo sync| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/at/;
$printable_key{$key} = q|at| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/getty/;
$printable_key{$key} = q|/sbin/getty| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/skel\/.profile/;
$printable_key{$key} = q|/etc/skel/.profile| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/version/;
$printable_key{$key} = q|/proc/version| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/modalit� utente singolo/;
$printable_key{$key} = q|modalit� utente singolo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/run/;
$printable_key{$key} = q|/var/run| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/mtab/;
$printable_key{$key} = q|/etc/mtab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/loggin/;
$printable_key{$key} = q|loggin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/log\/wtmp/;
$printable_key{$key} = q|/var/log/wtmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/syslog/;
$printable_key{$key} = q|syslog| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/free/;
$printable_key{$key} = q|free| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/setfdprm/;
$printable_key{$key} = q|setfdprm| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fsck/;
$printable_key{$key} = q|fsck| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tune2fs/;
$printable_key{$key} = q|tune2fs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/wtmp/;
$printable_key{$key} = q|wtmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mke2fs/;
$printable_key{$key} = q|mke2fs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/drive del floppy/;
$printable_key{$key} = q|drive del floppy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dischetti di installazione/;
$printable_key{$key} = q|dischetti di installazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/panic/;
$printable_key{$key} = q|panic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/getty/;
$printable_key{$key} = q|getty| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/sbin\/update/;
$printable_key{$key} = q|/sbin/update| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/time/;
$printable_key{$key} = q|time| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/controllo di un filesystem/;
$printable_key{$key} = q|controllo di un filesystem| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/athena/;
$printable_key{$key} = q|Athena| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/boot record/;
$printable_key{$key} = q|boot record| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/casella di posta in arrivo/;
$printable_key{$key} = q|casella di posta in arrivo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/comunicazione/;
$printable_key{$key} = q|comunicazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/lseek/;
$printable_key{$key} = q|lseek| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/montare/;
$printable_key{$key} = q|montare| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/vigr/;
$printable_key{$key} = q|vigr| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/telinit/;
$printable_key{$key} = q|telinit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenzauso/;
$printable_key{$key} = q|uso| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdown improprio/;
$printable_key{$key} = q|shutdown improprio| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/master boot record/;
$printable_key{$key} = q|master boot record| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/man/;
$printable_key{$key} = q|/var/man| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man\/cat*/;
$printable_key{$key} = q|/usr/man/cat*| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/lib/;
$printable_key{$key} = q|/lib| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/chsh/;
$printable_key{$key} = q|chsh| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/open look/;
$printable_key{$key} = q|Open Look| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/daemoninit/;
$printable_key{$key} = q|init| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystemroot/;
$printable_key{$key} = q|root| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/daemonat/;
$printable_key{$key} = q|at| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hda/;
$printable_key{$key} = q|/dev/hda| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/bootdal floppy di emergenza/;
$printable_key{$key} = q|dal floppy di emergenza| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdb/;
$printable_key{$key} = q|/dev/hdb| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/messaggi di errore/;
$printable_key{$key} = q|messaggi di errore| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdc/;
$printable_key{$key} = q|/dev/hdc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/hdd/;
$printable_key{$key} = q|/dev/hdd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/doc/;
$printable_key{$key} = q|/usr/doc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sistema operativo/;
$printable_key{$key} = q|sistema operativo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/xterm/;
$printable_key{$key} = q|xterm| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/modalit� testuale/;
$printable_key{$key} = q|modalit� testuale| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fdisk/;
$printable_key{$key} = q|fdisk| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/processi in backgrounde spegnimento del computer/;
$printable_key{$key} = q|e spegnimento del computer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cron/;
$printable_key{$key} = q|cron| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/interrupts/;
$printable_key{$key} = q|/proc/interrupts| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/makedev.local/;
$printable_key{$key} = q|/dev/MAKEDEV.local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mkswap/;
$printable_key{$key} = q|mkswap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tolleranza degli errori/;
$printable_key{$key} = q|tolleranza degli errori| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystem root a sola lettura/;
$printable_key{$key} = q|filesystem root a sola lettura| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shadow.group/;
$printable_key{$key} = q|/etc/shadow.group| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/include/;
$printable_key{$key} = q|/usr/include| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/chown/;
$printable_key{$key} = q|chown| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/messaggio/;
$printable_key{$key} = q|messaggio| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/terminale/;
$printable_key{$key} = q|terminale| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/driver dei filesystem/;
$printable_key{$key} = q|driver dei filesystem| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/user mode/;
$printable_key{$key} = q|user mode| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenza/;
$printable_key{$key} = q|floppy di emergenza| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/su/;
$printable_key{$key} = q|su| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/messaggio di shutdown/;
$printable_key{$key} = q|messaggio di shutdown| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dd/;
$printable_key{$key} = q|dd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/demonitelnet/;
$printable_key{$key} = q|telnet| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/avvio del computer/;
$printable_key{$key} = q|avvio del computer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/df/;
$printable_key{$key} = q|df| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gcc/;
$printable_key{$key} = q|GCC| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/spool/;
$printable_key{$key} = q|spool| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/stat/;
$printable_key{$key} = q|/proc/stat| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/rdate/;
$printable_key{$key} = q|rdate| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gestione della rete/;
$printable_key{$key} = q|gestione della rete| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fstab/;
$printable_key{$key} = q|fstab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mount/;
$printable_key{$key} = q|mount| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/du/;
$printable_key{$key} = q|du| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/tzset/;
$printable_key{$key} = q|tzset| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/home\/staff/;
$printable_key{$key} = q|/home/staff| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/interfaccia grafica utente/;
$printable_key{$key} = q|interfaccia grafica utente| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdown/;
$printable_key{$key} = q|shutdown| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/autenticazione degli utenti/;
$printable_key{$key} = q|autenticazione degli utenti| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/modalit� video/;
$printable_key{$key} = q|modalit� video| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/login.defs/;
$printable_key{$key} = q|/etc/login.defs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/info/;
$printable_key{$key} = q|/usr/info| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mount di filesystem/;
$printable_key{$key} = q|mount di filesystem| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystem/;
$printable_key{$key} = q|filesystem| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/cpuinfo/;
$printable_key{$key} = q|/proc/cpuinfo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppy di emergenzacreazione/;
$printable_key{$key} = q|creazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/group/;
$printable_key{$key} = q|/etc/group| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/demonirlogin/;
$printable_key{$key} = q|rlogin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/adduser/;
$printable_key{$key} = q|adduser| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystem virtuale/;
$printable_key{$key} = q|filesystem virtuale| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fdprm/;
$printable_key{$key} = q|/etc/fdprm| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cfdisk/;
$printable_key{$key} = q|cfdisk| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/userdel/;
$printable_key{$key} = q|userdel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/x11r6/;
$printable_key{$key} = q|/usr/X11R6| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/chfn/;
$printable_key{$key} = q|chfn| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/shadow/;
$printable_key{$key} = q|/etc/shadow| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/syslogd/;
$printable_key{$key} = q|syslogd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/linux filesystem standard/;
$printable_key{$key} = q|Linux Filesystem Standard| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/nfs/;
$printable_key{$key} = q|NFS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/casella di posta/;
$printable_key{$key} = q|casella di posta| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/skel/;
$printable_key{$key} = q|/etc/skel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/filesystems/;
$printable_key{$key} = q|/proc/filesystems| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/inittab/;
$printable_key{$key} = q|inittab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/vfs/;
$printable_key{$key} = q|VFS| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/initmodalit� utente singolo/;
$printable_key{$key} = q|modalit� utente singolo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/informatica distribuita/;
$printable_key{$key} = q|informatica distribuita| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/esecuzione periodica di comandi/;
$printable_key{$key} = q|esecuzione periodica di comandi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/spool/;
$printable_key{$key} = q|/var/spool| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cache/;
$printable_key{$key} = q|cache| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/crash di sistema/;
$printable_key{$key} = q|crash di sistema| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/inetd/;
$printable_key{$key} = q|inetd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/uccisione di processi/;
$printable_key{$key} = q|uccisione di processi| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/perdita dei dati/;
$printable_key{$key} = q|perdita dei dati| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/spegnere il computer/;
$printable_key{$key} = q|spegnere il computer| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/mtools/;
$printable_key{$key} = q|mtools| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/inite ctrl-alt-del/;
$printable_key{$key} = q|e ctrl-alt-del| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file/;
$printable_key{$key} = q|file| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/messaggi di avvio/;
$printable_key{$key} = q|messaggi di avvio| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gzexe/;
$printable_key{$key} = q|gzexe| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/local/;
$printable_key{$key} = q|/usr/local| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/dumpe2fs/;
$printable_key{$key} = q|dumpe2fs| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/spool\/mail/;
$printable_key{$key} = q|/var/spool/mail| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/settore di boot/;
$printable_key{$key} = q|settore di boot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/condivisione di stampanti/;
$printable_key{$key} = q|condivisione di stampanti| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/informatica centralizzata/;
$printable_key{$key} = q|informatica centralizzata| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/modules/;
$printable_key{$key} = q|/proc/modules| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/ramdisk/;
$printable_key{$key} = q|ramdisk| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/chmod/;
$printable_key{$key} = q|chmod| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/pine/;
$printable_key{$key} = q|pine| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/passwd/;
$printable_key{$key} = q|/etc/passwd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/runlevel/;
$printable_key{$key} = q|runlevel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/partizione attiva/;
$printable_key{$key} = q|partizione attiva| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/lock/;
$printable_key{$key} = q|/var/lock| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fsstnd/;
$printable_key{$key} = q|FSSTND| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/man/;
$printable_key{$key} = q|/usr/man| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/init/;
$printable_key{$key} = q|init| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file temporanei/;
$printable_key{$key} = q|file temporanei| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/shutdownazioni di/;
$printable_key{$key} = q|azioni di| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/filesystem standard/;
$printable_key{$key} = q|Filesystem Standard| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/home/;
$printable_key{$key} = q|/home| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/extra-swap/;
$printable_key{$key} = q|/extra-swap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/e2fsck/;
$printable_key{$key} = q|e2fsck| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/console virtuale/;
$printable_key{$key} = q|console virtuale| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/tmp/;
$printable_key{$key} = q|/tmp| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/magic/;
$printable_key{$key} = q|magic| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/boot/;
$printable_key{$key} = q|/boot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc/;
$printable_key{$key} = q|/proc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/issue/;
$printable_key{$key} = q|/etc/issue| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/sysvinit/;
$printable_key{$key} = q|sysvinit| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/piangere/;
$printable_key{$key} = q|piangere| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/local\/bin/;
$printable_key{$key} = q|/usr/local/bin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/termcap/;
$printable_key{$key} = q|termcap| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/montarefilesystem di root/;
$printable_key{$key} = q|filesystem di root| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/file di log/;
$printable_key{$key} = q|file di log| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/passwd/;
$printable_key{$key} = q|passwd| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/root/;
$printable_key{$key} = q|/root| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/mnt\/dosa/;
$printable_key{$key} = q|/mnt/dosa| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/smail/;
$printable_key{$key} = q|smail| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/configurazione del kernel/;
$printable_key{$key} = q|configurazione del kernel| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/chiamata di sistema/;
$printable_key{$key} = q|chiamata di sistema| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/multitasking/;
$printable_key{$key} = q|multitasking| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/demoni/;
$printable_key{$key} = q|demoni| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/var\/lib/;
$printable_key{$key} = q|/var/lib| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/linguaggio di programmazione/;
$printable_key{$key} = q|linguaggio di programmazione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/date/;
$printable_key{$key} = q|date| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/.hushlogin/;
$printable_key{$key} = q|.hushlogin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc?.d/;
$printable_key{$key} = q|/etc/rc?.d| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/find/;
$printable_key{$key} = q|find| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/ioports/;
$printable_key{$key} = q|/proc/ioports| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/update/;
$printable_key{$key} = q|update| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/init.d\/rc/;
$printable_key{$key} = q|/etc/init.d/rc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/fd0h1440/;
$printable_key{$key} = q|/dev/fd0H1440| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fdisk -l/;
$printable_key{$key} = q|fdisk -l| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fstab/;
$printable_key{$key} = q|/etc/fstab| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cpio/;
$printable_key{$key} = q|cpio| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/network file system/;
$printable_key{$key} = q|Network File System| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/rc/;
$printable_key{$key} = q|/etc/rc| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/lilo/;
$printable_key{$key} = q|LILO| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/bin/;
$printable_key{$key} = q|/usr/bin| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/usr\/x386/;
$printable_key{$key} = q|/usr/X386| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/relazioni sociali/;
$printable_key{$key} = q|relazioni sociali| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppybooting da/;
$printable_key{$key} = q|booting da| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/fork/;
$printable_key{$key} = q|fork| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/console/;
$printable_key{$key} = q|console| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sda/;
$printable_key{$key} = q|/dev/sda| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/dev\/sdb/;
$printable_key{$key} = q|/dev/sdb| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/boot recordpartizione/;
$printable_key{$key} = q|partizione| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/gzip/;
$printable_key{$key} = q|gzip| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/floppy/;
$printable_key{$key} = q|floppy| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/cache del disco/;
$printable_key{$key} = q|cache del disco| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/fastboot/;
$printable_key{$key} = q|/etc/fastboot| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/proc\/meminfo/;
$printable_key{$key} = q|/proc/meminfo| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/elm/;
$printable_key{$key} = q|elm| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

$key = q/\/etc\/csh.login/;
$printable_key{$key} = q|/etc/csh.login| unless ($printable_key{$key}); 
$noresave{$key} = "$nosave";

1;

