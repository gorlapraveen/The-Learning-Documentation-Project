'<LI><A HREF="'.$dir.'node39.html#1894">Tabella delle partizioni (dal programma <TT>fdisk</TT></A><A NAME="1996">&#160;</A> di Linux).
<LI><A HREF="'.$dir.'node77.html#3484">Numeri dei runlevel</A>'
