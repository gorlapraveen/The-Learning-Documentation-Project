# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="img4.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{figure}centersmallpreform<verbatim_mark>verbatim3#preformcenter{figure}FSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="927" HEIGHT="614"
 SRC="img10.gif"
 ALT="\begin{figure}
\begin{center}
\small
\begin{tex2html_preform}\begin{verbatim}dum...
... Free inodes: 35-360\end{verbatim}\end{tex2html_preform}\end{center}\end{figure}">|; 

$key = q/{}includegraphicsloginsslashlogins-via-terminals.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="481" HEIGHT="766" ALIGN="BOTTOM" BORDER="0"
 SRC="img12.gif"
 ALT="\includegraphics{logins/logins-via-terminals.ps}">|; 

$key = q/{inline}(4096-10)times8times4096=133890048{inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="267" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="img11.gif"
 ALT="$(4096-10)\times 8\times 4096 = 133890048$">|; 

$key = q/{}includegraphicswalkaboutslashfstree.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="457" HEIGHT="229" ALIGN="BOTTOM" BORDER="0"
 SRC="img3.gif"
 ALT="\includegraphics{walkabout/fstree.ps}">|; 

$key = q/{}includegraphicsdisksslashhd-mount-mounted.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="386" HEIGHT="193" ALIGN="BOTTOM" BORDER="0"
 SRC="img9.gif"
 ALT="\includegraphics{disks/hd-mount-mounted.ps}">|; 

$key = q/{}includegraphicsbackupsslashbackup-timeline.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="639" HEIGHT="99" ALIGN="BOTTOM" BORDER="0"
 SRC="img13.gif"
 ALT="\includegraphics{backups/backup-timeline.ps}">|; 

$key = q/{figure}centertabularrlllTape&Level&Backup&Recupero&&(giorni)&nastrihline1&0&nsl2,5,7,9,10,11dots&9&1&1,2,5,7,9,10,11,dotshlinetabularcenter{figure}FSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="376" HEIGHT="315"
 SRC="img14.gif"
 ALT="\begin{figure}
\begin{center}
\begin{tabular}{r l l l}
Tape & Level & Backup & R...
... & 1, 2, 5, 7, 9, 10, 11, \dots \\\\
\hline
\end{tabular}\end{center}\end{figure}">|; 

$key = q/{}includegraphicsdisksslashhd-schematic.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="348" HEIGHT="424" ALIGN="BOTTOM" BORDER="0"
 SRC="img5.gif"
 ALT="\includegraphics{disks/hd-schematic.ps}">|; 

$key = q/{}includegraphicsdisksslashhd-mount-separate.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="708" HEIGHT="103" ALIGN="BOTTOM" BORDER="0"
 SRC="img8.gif"
 ALT="\includegraphics{disks/hd-mount-separate.ps}">|; 

$key = q/{inline}ge{inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="img7.gif"
 ALT="$\ge$">|; 

$key = q/{}includegraphicsoverviewslashoverview-kernel.ps{}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="654" HEIGHT="571" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.gif"
 ALT="\includegraphics{overview/overview-kernel.ps}">|; 

1;

