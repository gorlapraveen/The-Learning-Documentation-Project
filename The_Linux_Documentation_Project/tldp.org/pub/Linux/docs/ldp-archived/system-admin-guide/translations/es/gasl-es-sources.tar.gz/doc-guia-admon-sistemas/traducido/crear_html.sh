#!/bin/sh

mkdir -p html/figuras
#for i in figuras/*fig ; do 
#    convert $i html/`echo $i | sed -e 's/.fig/.png/g' ` 
#done
cp figuras/*.png html/figuras/
xmlto html -o html/ index.xml &&
./corrector.sh *.xml
