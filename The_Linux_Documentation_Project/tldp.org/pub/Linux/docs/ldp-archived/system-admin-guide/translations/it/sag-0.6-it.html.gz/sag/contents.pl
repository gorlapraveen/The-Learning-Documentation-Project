# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate contents original text with physical files.


$key = q/0 0 4 3 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node19.html%:%Stampa| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%'."$dir".q|sag.html%:%Guida dell'amministratore di sistema Linux 0.6| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node2.html%:%Contents| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node6.html%:%Panoramica di un sistema Linux| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node7.html%:%Le varie parti di un sistema operativo| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node8.html%:%Le parti principali del kernel| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node29.html%:%Uso dei dischi e di altri mezzi di immagazzinamento| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node9.html%:%I principali servizi in un sistema UNIX| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node30.html%:%Due tipi di dispositivi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node67.html%:%Avvii e shutdown| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node20.html%:%La struttura del filesystem| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node24.html%:%La directory <TT>/etc</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node31.html%:%Gli hard disk| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node68.html%:%Introduzione agli avvii e agli shutdown| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node11.html%:%Login dai terminali| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node32.html%:%I floppy| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node33.html%:%I CD-ROM| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node69.html%:%Il processo di boot pi� da vicino| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node34.html%:%I nastri| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node13.html%:%Esecuzione periodica dei comandi: <TT>cron</TT> e <TT>at</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node70.html%:%Ancora sullo shutdown| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node35.html%:%La formattazione| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node71.html%:%Il reboot| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node36.html%:%Le partizioni| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node15.html%:%Le reti| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node72.html%:%Modalit� utente singolo| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node42.html%:%I filesystem| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 8 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node73.html%:%Emergency boot floppies| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node38.html%:%Partizioni estese e partizioni logiche| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node17.html%:%Filesystem di rete| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node53.html%:%Dischi senza filesystem| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node44.html%:%Filesystem a go-go| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node40.html%:%Ripartizionare un hard disk| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node80.html%:%Login e logout| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node46.html%:%Creare un filesystem| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node81.html%:%Login via terminale| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node82.html%:%Login via rete| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node97.html%:%I backup| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node48.html%:%Il controllo dell'integrit� di un filesystem con <TT>fsck</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node83.html%:%Che cosa fa <TT>login</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node98.html%:%Sull'importanza delle copie di backup| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node84.html%:%X e xdm| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node90.html%:%<TT>/etc/passwd</TT> ed altri file informativi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node99.html%:%La scelta del mezzo di backup| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node112.html%:%Misurare i buchi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node50.html%:%Combattere la frammentazione| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node85.html%:%Il controllo degli accessi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node100.html%:%La scelta dello strumento di backup| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node54.html%:%Allocare spazio disco| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 10 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node86.html%:%L'avvio della shell| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node92.html%:%Ambiente iniziale: <TT>/etc/skel</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node101.html%:%Backup semplici| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node114.html%:%Bibliography| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node104.html%:%Backup multilivello| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node56.html%:%Requisiti di spazio| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node103.html%:%Recuperare file con <TT>tar</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node105.html%:%Di che fare backup| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node116.html%:%About this document ... %:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node106.html%:%Backup compressi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node58.html%:%Aggiungere altro spazio disco per Linux| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node1.html%:%Sommario%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node3.html%:%Introduzione| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node4.html%:%Convenzioni tipografiche%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node21.html%:%L'albero delle directory| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node5.html%:%Il Linux Documentation Project%:%<tex2html_star_mark>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node22.html%:%Premesse| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node23.html%:%Il filesystem root| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node60.html%:%La gestione della memoria| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node26.html%:%Il filesystem <TT>/usr</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node10.html%:%<TT>init</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node61.html%:%Cos'� la memoria virtuale?| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node27.html%:%Il filesystem <TT>/var</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node25.html%:%La directory <TT>/dev</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node62.html%:%La creazione di uno spazio di swap| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node74.html%:%<TT>init</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node75.html%:%<TT>init</TT> prima di tutto| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node63.html%:%Come si usa lo spazio di swap| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node12.html%:%Syslog| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 5 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node28.html%:%Il filesystem <TT>/proc</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node76.html%:%Configurazione di <TT>init</TT> per inizializzare le <TT>getty</TT>: il file <TT>/etc/inittab</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node64.html%:%La condivisione dello spazio di swap con altri sistemi operativi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node77.html%:%I runlevel| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node65.html%:%Allocare lo spazio di swap| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node14.html%:%GUI - interfaccia grafica utente| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node78.html%:%Configurazioni speciali in <TT>/etc/inittab</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 7 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node66.html%:%La cache di buffer| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 9 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node79.html%:%Fare il boot in modalit� utente singolo| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node16.html%:%Login in rete| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node37.html%:%Il MBR, i settori di boot e la tabella delle partizioni| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node43.html%:%Che cosa sono i filesystem?| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 4 3 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node18.html%:%Posta| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node39.html%:%Tipi di partizione| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node45.html%:%Quale filesystem bisogna usare?| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 7 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node41.html%:%File di device e partizioni| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node87.html%:%Gestire gli account degli utenti| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node47.html%:%Montare e smontare| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node88.html%:%Che cos'� un account?| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node89.html%:%Come creare un utente| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node107.html%:%Tenere il tempo| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node49.html%:%Il controllo degli errori sul disco con <TT>badblocks</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node94.html%:%Modifica delle propriet� degli utenti| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 13 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node108.html%:%I fusi orari| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node91.html%:%Gli identificativi numerici per gli utenti e i gruppi| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node95.html%:%Rimozione di un utente| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 13 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node109.html%:%Gli orologi hardware e software| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node113.html%:%Glossario (BOZZA)| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node51.html%:%Altri strumenti per tutti i filesystem| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node96.html%:%Disabilitazione temporanea di un utente| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 13 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node110.html%:%Impostazione e lettura dell'ora| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node55.html%:%Schemi di partizionamento| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 11 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node93.html%:%Creazione manuale di un utente| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 12 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node102.html%:%Fare backup con <TT>tar</TT>| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 13 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%'."$dir".q|node111.html%:%Quando l'orologio si sbaglia| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '2%:%'."$dir".q|node115.html%:%Index| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node57.html%:%Esempi di allocazione di hard disk| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 10 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node59.html%:%Suggerimenti per risparmiare lo spazio su disco| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

$key = q/0 0 6 8 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%'."$dir".q|node52.html%:%Altri strumenti per il filesystem ext2| unless ($toc_section_info{$key}); 
$noresave{$key} = "$nosave";

1;

