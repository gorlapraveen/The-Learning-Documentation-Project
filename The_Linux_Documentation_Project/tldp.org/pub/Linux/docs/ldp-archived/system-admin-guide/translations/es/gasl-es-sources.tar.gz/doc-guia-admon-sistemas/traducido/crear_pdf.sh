#!/bin/sh

mkdir pdf
cp figuras/*.png pdf

fop -xml index.xml -xsl /usr/share/xml/docbook/stylesheet/ldp/ldp-print.xsl -foout pdf/index.fo
cd pdf/

cat index.fo | #sed -e 's/font-family="sans-serif/font-family="serif/g' |
               sed -e 's/margin-top="0.5/margin-top="1/g' | 
               sed -e 's/margin-bottom="0.5/margin-bottom="1/g'  >> index.tmp
rm index.fo 
mv index.tmp index.fo
fop index.fo libro.pdf &&

cd .. &&
./corrector.sh *.xml


# cd /tmp/traducido/pdf
# for i in *.png ; do convert $i `echo $i|sed -e 's/png/jpg/'` ; done
#
# <fo:block id="terminal-logins">
# <fo:external-graphic src="url('file:///tmp/traducido/pdf/logins-via-terminals.jpg')" content-width="3in" content-height="4in"/>
# <fo:inline>
# <fo:block> Figura 8.1. Accediendo a trav&#xE9;s de terminales: la interacci&#xF3;n de init, getty, login y el int&#xE9;rprete
#  de comandos.
# </fo:block>
# </fo:inline>
# </fo:block>
# <fo:block space-before.optimum="1em" space-before.minimum="0.8em" space-before.maximum="1.2em">
# </fo:block>

