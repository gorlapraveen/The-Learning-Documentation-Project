# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate labels original text with physical files.


$key = q/chap:walkabout/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bootdisk-howto/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-mount-all/;
$external_labels{$key} = "$URL/" . q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:boothalt/;
$external_labels{$key} = "$URL/" . q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:terminal-logins/;
$external_labels{$key} = "$URL/" . q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mkfs/;
$external_labels{$key} = "$URL/" . q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:backup-history-timeline/;
$external_labels{$key} = "$URL/" . q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-mount-root/;
$external_labels{$key} = "$URL/" . q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filesystems/;
$external_labels{$key} = "$URL/" . q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:boot-closeup/;
$external_labels{$key} = "$URL/" . q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:manual-adduser/;
$external_labels{$key} = "$URL/" . q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:mount/;
$external_labels{$key} = "$URL/" . q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fsstnd-1.2/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:dumpe2fs-output/;
$external_labels{$key} = "$URL/" . q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-schematic/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_device-list/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:useradmin/;
$external_labels{$key} = "$URL/" . q|node87.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:time/;
$external_labels{$key} = "$URL/" . q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:swap-alloc/;
$external_labels{$key} = "$URL/" . q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:overview/;
$external_labels{$key} = "$URL/" . q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:buffer-cache/;
$external_labels{$key} = "$URL/" . q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:measure-holes/;
$external_labels{$key} = "$URL/" . q|node112.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:logins/;
$external_labels{$key} = "$URL/" . q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hard-disk-layout/;
$external_labels{$key} = "$URL/" . q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:mem/;
$external_labels{$key} = "$URL/" . q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:kernel-overview/;
$external_labels{$key} = "$URL/" . q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:single-user-mode/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:partition-ids/;
$external_labels{$key} = "$URL/" . q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:fstree/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:init/;
$external_labels{$key} = "$URL/" . q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:efficient-backup-levels/;
$external_labels{$key} = "$URL/" . q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_getting-started/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:NFS/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ext2-defrag/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:run-levels/;
$external_labels{$key} = "$URL/" . q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:backups/;
$external_labels{$key} = "$URL/" . q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_network-admin-guide/;
$external_labels{$key} = "$URL/" . q|node114.html|; 
$noresave{$key} = "$nosave";

1;

