# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/chap:walkabout/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bootdisk-howto/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-mount-all/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:boothalt/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:terminal-logins/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mkfs/;
$ref_files{$key} = "$dir".q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:backup-history-timeline/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-mount-root/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:filesystems/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:boot-closeup/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:manual-adduser/;
$ref_files{$key} = "$dir".q|node93.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:mount/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fsstnd-1.2/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:dumpe2fs-output/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hd-schematic/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_device-list/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:useradmin/;
$ref_files{$key} = "$dir".q|node87.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:time/;
$ref_files{$key} = "$dir".q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:swap-alloc/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:overview/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:buffer-cache/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:measure-holes/;
$ref_files{$key} = "$dir".q|node112.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:logins/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:hard-disk-layout/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:mem/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:kernel-overview/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:single-user-mode/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:partition-ids/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:fstree/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/ch:init/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:efficient-backup-levels/;
$ref_files{$key} = "$dir".q|node104.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_getting-started/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:NFS/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ext2-defrag/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:run-levels/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/chap:backups/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_network-admin-guide/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

1;

