#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COMPARISON_ERROR 1
#define MAXTESTS 50
#define MAX_WLEN 24
#define MAX_SPAN 25

const char Wordfile[] = "word.lst";

typedef enum { FAIL, SUCCESS } Rflag;

/*********************PROTOTYPES***********************************/
Rflag l_search( char *search_word, FILE *fp );
Rflag b_search( char *search_word, FILE *fp, long left, long right );
Rflag lookup( char *test_word );
