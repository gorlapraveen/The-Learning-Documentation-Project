/**********************************************************************

      Header file for both stand-alone and Tcl front end programs.

**********************************************************************/


#define STARTINGYEAR 1
#define SECTIONLEN 12
/* Break into 1-year (12 pmt.) sections */
#define ANSWERLEN 30
#define FILENAMELEN 40
#define LINE_WIDTH 80
#define DZERO 0.0
#define MAXNUMLEN 40
#define NULL_ '\0'
#define CR "\n"
#define CR_ '\n'

/********************* Prototypes **************************/

void calculate( double principal0, double interest_rate, int months, 
                int fylen, char *savefilename );
void totals( int year, double yr_prin, double yr_int , FILE *tf );
void print_headers( FILE *tf );
void center ( char *strng , FILE *targetfile );
void digit_filter( char *rawnumber );
