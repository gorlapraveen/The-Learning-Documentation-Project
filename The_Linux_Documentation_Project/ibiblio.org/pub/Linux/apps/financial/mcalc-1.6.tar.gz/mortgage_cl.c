/* "Loan Calculator 1.5": Jeff's quick and dirty loan calculator,
   (C) 1997 Jeff Schmidt, see file 'COPYING' for terms of license.  This 
   program takes a dollar amount, interest rate in decimal notation, and
   duration of the loan in months, and outputs the amount of the monthly
   payment, as well as a chart of monthly quantities.

   Program modified by M. Cooper (thegrendel@theriver.com) 05/98

   This version of the mortgage program is totallycommand-line driven
         and should be invoked with the Tcl front-end, "mortgage".

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "mortgage.h"


int main( int argc, char **argv )

{

     int months,
         firstyrlen;
     double interest_rate,
            princip;
     char answer [ANSWERLEN],
          filename [FILENAMELEN];



/*        
	printf("This program is distributed under the GPL (see file 'COPYING'). lcalc 1.5\n"
		"is provided AS IS, and in no way carries any warranty expressed or implied.\n"
	 	"This includes any warranty regarding the accuracy of the output of lcalc 1.5\n");
*/

        strcpy( answer, *( argv + 1 ) );
        digit_filter( answer );    /*** To accept comma-formatted input ***/

        princip = atof( answer );

        interest_rate = atof( *( argv + 2 ) );
 
        months = atoi( *( argv + 3 ) ); 
 
           if( argc > 4 )
              firstyrlen = atoi( *( argv + 4 ) );
           else
              firstyrlen = SECTIONLEN;
   
           if( !isdigit( **( argv + 4 ) ) )
              firstyrlen = SECTIONLEN;


        if( argc > 5 )
           strcpy( filename, *( argv + 5 ) );
        else 
           strcpy( filename, "savefile" );

        if( !isalnum ( **( argv + 5 ) ) )
           strcpy( filename, "savefile" );




        calculate( princip, interest_rate, months, firstyrlen, filename );

        return (0);

}


void calculate( double principal, double int_rate, int mos, int fyrlen, char *ofilename )
{
     int x,
         index,
         lines,
         yr = STARTINGYEAR;
     double balance,
            top, 
            bottom = 1.0, 
            payment, 
            money_owed, 
            prin_pmt,
            interest = DZERO,
            int_acrued = DZERO,
            yac_prin = DZERO,
            yac_int = DZERO;
     FILE *of;
     

        of = fopen( ofilename, "w" );   

	if (int_rate >= 1.0)
		int_rate /= 100.0;

        fprintf( of, "\nprincipal = $%-9.2lf, Interest Rate = %-lf%%, Duration = " 
                "%d months.\n", principal, int_rate * 100.0, mos);

        

        int_rate = (int_rate / 12.0) + 1.0;



        top = principal * pow(int_rate, (double)mos);



        for (x = mos - 1; x > 0; x--)
                bottom += pow(int_rate, (double)x);

        

        payment = (top / bottom);

/*******Eliminate round-off error****************/
        payment *= 100.0;
        payment = rint( payment );
        payment /= 100.0;
/************************************************/




        fprintf( of, "\n                    ------------------------------------"
                "----\n");


        fprintf( of, "                     Payment equals $%.2lf a month.\n", payment);


        fprintf( of, "                    ------------------------------------"
                "----\n\n");



        balance = principal;


        



        print_headers( of );


        for (index = 1, lines = 1; index <= mos; index++, lines++)

        {

                

                if ( lines > SECTIONLEN  || 
                     lines > fyrlen && yr == STARTINGYEAR )

                {       

 
                totals( yr, yac_prin, yac_int, of );
                /* Print totals for year */


/*                  printf("\f\n           ");     */
/*                  Form Feed                      */

                        print_headers( of );

                        lines = 1;
                        yac_prin = 0.0;
                        yac_int = 0.0;
                        yr++;

                }

                

                interest = (balance * (int_rate - 1.0));
/***************Eliminate round-off error*********/
                interest*= 100.0;
                interest= rint( interest );
                interest /= 100.0;
/************************************************/

                money_owed = balance + interest;

                int_acrued += interest;


                if( index < mos )
                   prin_pmt = payment - interest;
                else
                   prin_pmt = balance;
/*****************Make provision for final payment****************/




                yac_prin += prin_pmt;
                yac_int += interest;
                
                if( index < mos )
                    balance = money_owed - payment;
                else
                    balance = 0.0;
/*****************Make provision for final payment****************/
                


           fprintf( of, "           %-5d |  %7.2lf   %7.2lf   %9.2lf" 
                   "      |  %10.2lf\n", index, prin_pmt, interest, 
                   int_acrued, balance );


        }


 

                totals( yr, yac_prin, yac_int, of );
                      /* Print final totals  */



        fprintf( of, CR );

        fprintf( of, "Final payment = $%-9.2lf", money_owed );

        fprintf( of, CR );

        for(index = 1; index < 80; index++) 

                fprintf( of, "_" );


        fprintf( of, CR );
        center( "Thank you for using Loan Calculator 1.5: Jeff's FAST loan amortizer.", of );
        center( "(C) 1997 Jeff Schmidt (jschmidt@ripco.com).", of );
        center( "Modified by M\\Cooper (thegrendel@theriver.com) 05/98", of );
	center( "Distributed under the terms of the GNU General Public License.", of );
        

        fclose ( of );

        return; 



}






void totals( int year, double yr_prin, double yr_int, FILE *of )
{

 
      fprintf( of, CR );
      fprintf( of, "Year %2d Totals    %9.2lf %9.2lf",
               year, yr_prin, yr_int );
      fprintf( of, CR CR CR );

      return;

}


void print_headers( FILE *of )
{

/********************************************************************
        printf("           Month | Bal. Comp.  - payment  = Balance "  
                "  | Int. Accrued\n"); 
        Original Code 
********************************************************************/

        fprintf( of, "           Month | Principal Interest  Int. Accrued"  
                "    |    Balance\n"); 

        fprintf( of, "           -----------------------------------------------"
                "----------\n");
        
        return;
}


void center ( char *string , FILE *tfile )

{
    int leading_spaces;

        leading_spaces = ( LINE_WIDTH - strlen(string) ) / 2 ;

        fprintf( tfile, "%*s%s\n", leading_spaces, "", string );

        return;
}


void digit_filter( char *rnumber )
{
   register i = 0,
            j = 0;
   int t;
   char temp[MAXNUMLEN];

      while( ( t =  *( rnumber + i++ ) ) !=  NULL_ )
           if( isdigit( t ) || t == '.' )
               *( temp + j++ ) = t;

      *( temp + i ) = NULL_;   /**** NULL terminate string. ****/

      strcpy( rnumber, temp );

      return;
}



/*

__crt0_glob_function()
{}

__crt0_load_environment_file()
{}

__crt0_setup_arguments()
{}

*/
